"""
Test script for camera fallback mode - image upload functionality
This demonstrates how the system can work with still image uploads when camera fails
"""

import json

import cv2
import numpy as np

from src.camera_system import CameraSystem

# Test configuration with fallback mode enabled
test_config = {
    "fallback_mode": True,
    "camera": {"source": 0, "width": 640, "height": 480, "fps": 10, "pi_camera": False},
    "detection": {
        "model": "yolov8n.pt",
        "confidence": 0.5,
        "device": "cpu",
        "track_history": 30,
    },
}

print("=" * 60)
print("Testing Camera Fallback Mode (Image Upload)")
print("=" * 60)

# Initialize camera system in fallback mode
print("\n1. Initializing camera system in fallback mode...")
camera_system = CameraSystem(test_config)

# Start the system (should skip camera init)
print("2. Starting camera system...")
started = camera_system.start()
print(f"   System started: {started}")

# Check status
print("\n3. Checking system status...")
status = camera_system.get_current_status()
print(f"   Fallback mode: {status['fallback_mode']}")
print(f"   Current detections: {status['human_count']}")
print(f"   Has frame: {status['has_frame']}")

# Create a test image (simple colored rectangle with simulated person)
print("\n4. Creating test image...")
test_image = np.zeros((480, 640, 3), dtype=np.uint8)
# Fill with solid color background
test_image[:, :] = [100, 150, 200]
# Add some rectangles to simulate objects
cv2.rectangle(test_image, (200, 150), (440, 400), (255, 255, 255), -1)
cv2.putText(
    test_image,
    "TEST IMAGE",
    (220, 250),
    cv2.FONT_HERSHEY_SIMPLEX,
    1,
    (0, 0, 0),
    2,
)

# Save test image
test_image_path = "test_upload_image.jpg"
cv2.imwrite(test_image_path, test_image)
print(f"   Test image saved to: {test_image_path}")

# Process the uploaded image
print("\n5. Processing uploaded test image...")
result = camera_system.process_uploaded_image(test_image)
print(f"   Processing result: {json.dumps(result, indent=2)}")

# Check updated status
print("\n6. Checking updated system status...")
status = camera_system.get_current_status()
print(f"   Human count: {status['human_count']}")
print(f"   Stable count: {status['stable_count']}")
print(f"   Last upload: {status['last_upload_time']}")

# Stop the system
print("\n7. Stopping camera system...")
camera_system.stop()
print("   System stopped")

print("\n" + "=" * 60)
print("Test completed successfully!")
print("=" * 60)
print("\nTo use fallback mode in production:")
print("1. Set 'fallback_mode': true in config.json")
print("2. Start the application normally")
print("3. Upload images via web interface or POST to /api/camera/upload")
print("4. System will detect people and control lights accordingly")
