import base64
import json
import logging
import os
import threading
import time
from datetime import date, datetime
from typing import Dict, List

import cv2
import numpy as np
from flask import Flask, Response, jsonify, render_template, request
from flask_socketio import SocketIO, emit

# Import our custom modules
from src.camera_system import CameraSystem, encode_frame_to_jpeg, resize_frame_for_web
from src.capture_logger import save_frame_and_log
from src.energy_monitor import EnergyMonitor
from src.lighting_system import LightingSystem
from src.zone_manager import ZoneManager

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class SmartLightingApp:
    """Main application class for the smart lighting system"""

    def __init__(self, config_file: str = "config.json"):
        # Load configuration
        self.config = self.load_config(config_file)

        # Initialize Flask app
        self.app = Flask(__name__)
        self.app.config["SECRET_KEY"] = "smart_lighting_secret_key_2024"
        # Use eventlet instead of threading for better compatibility
        self.socketio = SocketIO(
            self.app, cors_allowed_origins="*", async_mode="threading"
        )

        # Initialize system components
        self.camera_system = None
        self.zone_manager = None
        self.lighting_system = None
        self.energy_monitor = None

        # Application state
        self.running = False
        self.main_loop_thread = None
        self.last_update_time = time.time()

        # Setup routes
        self.setup_routes()
        self.setup_socket_events()

    def load_config(self, config_file: str) -> dict:
        """Load configuration from file"""
        try:
            if os.path.exists(config_file):
                with open(config_file, "r") as f:
                    config = json.load(f)
            else:
                # Load from example config
                with open("config.example.json", "r") as f:
                    config = json.load(f)

                # Save as main config
                with open(config_file, "w") as f:
                    json.dump(config, f, indent=2)

                logger.info(f"Created config file from example: {config_file}")

            return config
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise

    def initialize_systems(self):
        """Initialize all system components"""
        try:
            # Initialize camera system
            self.camera_system = CameraSystem(self.config)
            if not self.camera_system.start():
                raise RuntimeError("Failed to start camera system")

            # Initialize zone manager
            self.zone_manager = ZoneManager(self.config.get("zones", {}))

            # Initialize lighting system
            self.lighting_system = LightingSystem(self.config.get("lighting", {}))

            # If there are no lights configured but zones define light_ids, register them
            try:
                existing_lights = self.lighting_system.get_all_lights()
                if not existing_lights:
                    # Preferred GPIO pins for lights (BCM)
                    lighting_cfg = self.config.get("lighting", {})
                    default_pins = lighting_cfg.get("gpio_pins", [17, 22, 27])
                    pin_index = 0
                    zones = self.zone_manager.get_all_zones()
                    for zone_id, zone in zones.items():
                        for lid in zone.light_ids:
                            if self.lighting_system.get_light(lid) is None:
                                pin = default_pins[pin_index % len(default_pins)]
                                # Use zone name as light name
                                self.lighting_system.register_light(
                                    light_id=lid,
                                    name=zone.name or f"light_{pin}",
                                    pin=pin,
                                    power_watts=15.0,
                                    zone_ids=[zone_id],
                                )
                                pin_index += 1
            except Exception as e:
                logger.warning(f"Auto-registering lights from zones failed: {e}")

            # Initialize energy monitor
            self.energy_monitor = EnergyMonitor(self.config.get("energy", {}))

            logger.info("All systems initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize systems: {e}")
            self.cleanup()
            raise

    def start_main_loop(self):
        """Start the main lighting control loop in a separate thread"""
        if self.main_loop_thread is None or not self.main_loop_thread.is_alive():
            self.running = True
            self.main_loop_thread = threading.Thread(target=self.main_loop, daemon=True)
            self.main_loop_thread.start()
            logger.info("Main loop started successfully")
        else:
            logger.warning("Main loop is already running")

    def setup_routes(self):
        """Setup Flask routes"""

        @self.app.route("/")
        def index():
            return render_template("index.html")

        @self.app.route("/api/health")
        def api_health():
            """Health check endpoint"""
            return jsonify(
                {
                    "status": "ok",
                    "systems_ready": self.all_systems_ready(),
                    "main_loop_running": self.running
                    and self.main_loop_thread
                    and self.main_loop_thread.is_alive(),
                    "timestamp": datetime.now().isoformat(),
                }
            )

        @self.app.route("/zones")
        def zones():
            return render_template("index_spa.html")

        @self.app.route("/lights")
        def lights():
            return render_template("index_spa.html")

        @self.app.route("/energy")
        def energy():
            return render_template("index_spa.html")

        @self.app.route("/debug")
        def debug():
            """Debug endpoint to test basic functionality"""
            try:
                zones_count = (
                    len(self.zone_manager.get_all_zones()) if self.zone_manager else 0
                )
                lights_count = (
                    len(self.lighting_system.get_all_lights())
                    if self.lighting_system
                    else 0
                )
                return f"Debug: {zones_count} zones, {lights_count} lights, Systems ready: {self.all_systems_ready()}"
            except Exception as e:
                return f"Debug error: {str(e)}"

        @self.app.route("/monitor")
        def monitor():
            """Real-time monitoring dashboard"""
            return render_template("index_spa.html")

        # API Routes
        @self.app.route("/api/status")
        def api_status():
            """Get system status"""
            if not self.all_systems_ready():
                return jsonify({"error": "Systems not initialized"}), 503

            camera_status = self.camera_system.get_current_status()
            lighting_status = self.lighting_system.get_system_status()
            zone_stats = self.zone_manager.get_zone_statistics()

            # Get zone data and calculate summary stats
            all_zones = self.zone_manager.get_all_zones()
            active_zones = sum(
                1 for zone in all_zones.values() if zone.current_occupancy > 0
            )
            total_people = sum(zone.current_occupancy for zone in all_zones.values())

            return jsonify(
                {
                    "camera": {
                        "human_count": camera_status.get("human_count", 0),
                        "has_frame": camera_status.get("has_frame", False),
                    },
                    "lights": {
                        "total_lights": lighting_status.get("total_lights", 0),
                        "lights_on": lighting_status.get("lights_on", 0),
                        "lights_off": lighting_status.get("lights_off", 0),
                    },
                    "zones": {
                        "total_zones": len(all_zones),
                        "active_zones": active_zones,
                        "total_people": total_people,
                    },
                    "energy": {
                        "current_power": self.energy_monitor.get_current_power_consumption(),
                        "currency": self.energy_monitor.currency,
                    },
                    "main_loop_running": self.running
                    and self.main_loop_thread
                    and self.main_loop_thread.is_alive(),
                    "timestamp": datetime.now().isoformat(),
                }
            )

        @self.app.route("/api/restart_main_loop", methods=["POST"])
        def api_restart_main_loop():
            """Restart the main loop if it stopped"""
            try:
                if not (
                    self.running
                    and self.main_loop_thread
                    and self.main_loop_thread.is_alive()
                ):
                    logger.info("Restarting main loop...")
                    self.start_main_loop()
                    return jsonify({"status": "Main loop restarted", "success": True})
                else:
                    return jsonify(
                        {"status": "Main loop is already running", "success": True}
                    )
            except Exception as e:
                logger.error(f"Failed to restart main loop: {e}")
                return jsonify({"error": str(e), "success": False}), 500

        @self.app.route("/api/camera/snapshot")
        def api_camera_snapshot():
            """Get camera snapshot for zone definition"""
            if not self.camera_system:
                return jsonify({"error": "Camera not available"}), 503

            frame = self.camera_system.capture_snapshot()
            if frame is None:
                return jsonify({"error": "No frame available"}), 503

            # Resize for web display
            frame = resize_frame_for_web(frame, 800)

            # Set as reference frame
            self.zone_manager.set_reference_frame(frame)

            # Encode to base64
            _, buffer = cv2.imencode(".jpg", frame)
            frame_b64 = base64.b64encode(buffer).decode("utf-8")

            return jsonify(
                {
                    "image": f"data:image/jpeg;base64,{frame_b64}",
                    "width": frame.shape[1],
                    "height": frame.shape[0],
                    "timestamp": datetime.now().isoformat(),
                }
            )

        # Note: image upload fallback removed - system relies on live camera feed

        @self.app.route("/api/camera/stream")
        def api_camera_stream():
            """Video streaming route for API endpoint"""
            return Response(
                self.generate_video_feed(),
                mimetype="multipart/x-mixed-replace; boundary=frame",
            )

        @self.app.route("/api/zones", methods=["GET", "POST"])
        def api_zones():
            """Zone management API"""
            if request.method == "GET":
                try:
                    zones = self.zone_manager.get_all_zones()
                    logger.info(f"API: Returning {len(zones)} zones")
                    zone_dict = {
                        zone_id: zone.to_dict() for zone_id, zone in zones.items()
                    }
                    return jsonify({"zones": zone_dict})
                except Exception as e:
                    logger.error(f"API: Error getting zones: {e}")
                    return jsonify({"error": str(e)}), 500

            elif request.method == "POST":
                data = request.get_json() or {}
                try:
                    # Basic validation
                    if "name" not in data or not data["name"].strip():
                        return jsonify({"error": "Zone name is required"}), 400
                    if (
                        "points" not in data
                        or not isinstance(data["points"], list)
                        or len(data["points"]) < 3
                    ):
                        return (
                            jsonify({"error": "Zone must include at least 3 points"}),
                            400,
                        )

                    zone_id = self.zone_manager.create_zone(
                        name=data["name"].strip(),
                        points=data["points"],
                        light_ids=data.get("light_ids", []),
                    )

                    # Return full zone data for immediate UI update
                    zone = self.zone_manager.get_zone(zone_id)
                    logger.info(
                        f"API: Created zone {zone_id} ({data['name']}) with {len(data['points'])} points"
                    )
                    return jsonify(
                        {"zone_id": zone_id, "zone": zone.to_dict(), "success": True}
                    )
                except Exception as e:
                    logger.error(f"API: Failed to create zone - {e}")
                    return jsonify({"error": str(e)}), 400

        @self.app.route("/api/zones/<zone_id>", methods=["PUT", "DELETE"])
        def api_zone_detail(zone_id):
            """Individual zone management"""
            if request.method == "PUT":
                data = request.get_json()
                try:
                    success = self.zone_manager.update_zone(
                        zone_id=zone_id,
                        name=data.get("name"),
                        points=data.get("points"),
                        light_ids=data.get("light_ids"),
                        enabled=data.get("enabled"),
                    )
                    return jsonify({"success": success})
                except Exception as e:
                    return jsonify({"error": str(e)}), 400

            elif request.method == "DELETE":
                success = self.zone_manager.delete_zone(zone_id)
                return jsonify({"success": success})

        @self.app.route("/api/lights", methods=["GET", "POST"])
        def api_lights():
            """Light management API"""
            if request.method == "GET":
                try:
                    lights = self.lighting_system.get_all_lights()
                    logger.info(f"API: Returning {len(lights)} lights")
                    lights_dict = {
                        light_id: light.to_dict() for light_id, light in lights.items()
                    }
                    return jsonify({"lights": lights_dict})
                except Exception as e:
                    logger.error(f"API: Error getting lights: {e}")
                    return jsonify({"error": str(e)}), 500

            elif request.method == "POST":
                data = request.get_json()
                try:
                    light_id = self.lighting_system.create_light(
                        name=data["name"],
                        pin=data.get("pin"),
                        power_watts=data.get("power_watts", 15.0),
                        zone_ids=data.get("zone_ids", []),
                    )
                    return jsonify({"light_id": light_id, "success": True})
                except Exception as e:
                    return jsonify({"error": str(e)}), 400

        @self.app.route("/api/lights/<light_id>", methods=["PUT", "DELETE"])
        def api_light_detail(light_id):
            """Individual light management"""
            if request.method == "PUT":
                data = request.get_json()

                if "control" in data:
                    # Light control (no brightness)
                    desired_state = data["control"].get("state", False)
                    light = self.lighting_system.get_light(light_id)
                    previous_state = light.is_on if light else None
                    success = self.lighting_system.control_light(
                        light_id=light_id,
                        state=desired_state,
                        manual=data["control"].get("manual", False),
                    )
                    # Record energy event
                    light = self.lighting_system.get_light(light_id)
                    if light and success and previous_state != desired_state:
                        self.energy_monitor.record_light_event(
                            light_id=light_id,
                            light_name=light.name,
                            event="on" if desired_state else "off",
                            power_watts=light.power_watts,
                        )
                    return jsonify({"success": success})
                else:
                    # Light configuration update
                    try:
                        success = self.lighting_system.update_light(
                            light_id=light_id,
                            name=data.get("name"),
                            pin=data.get("pin"),
                            power_watts=data.get("power_watts"),
                            zone_ids=data.get("zone_ids"),
                        )
                        return jsonify({"success": success})
                    except Exception as e:
                        return jsonify({"error": str(e)}), 400

            elif request.method == "DELETE":
                success = self.lighting_system.delete_light(light_id)
                return jsonify({"success": success})

        @self.app.route("/api/lights/auto-control", methods=["GET", "POST"])
        def api_lights_auto_control():
            """Auto control management"""
            if request.method == "GET":
                return jsonify(
                    {"auto_control_enabled": self.lighting_system.auto_control_enabled}
                )

            elif request.method == "POST":
                data = request.get_json()
                enabled = data.get("enabled", True)
                self.lighting_system.set_auto_control(enabled)
                if enabled:
                    self.lighting_system.clear_all_manual_overrides()
                return jsonify(
                    {
                        "auto_control_enabled": self.lighting_system.auto_control_enabled,
                        "success": True,
                    }
                )

        @self.app.route("/api/energy/daily")
        def api_energy_daily():
            """Get daily energy usage"""
            target_date = request.args.get("date")
            if target_date:
                target_date = datetime.fromisoformat(target_date).date()

            return jsonify(self.energy_monitor.get_daily_usage(target_date))

        @self.app.route("/api/energy/monthly")
        def api_energy_monthly():
            """Get monthly energy usage"""
            year = request.args.get("year", type=int)
            month = request.args.get("month", type=int)

            return jsonify(self.energy_monitor.get_monthly_usage(year, month))

        @self.app.route("/api/energy/weekly")
        def api_energy_weekly():
            """Get weekly energy usage"""
            start_date = request.args.get("start_date")
            if start_date:
                start_date = datetime.fromisoformat(start_date).date()

            return jsonify(self.energy_monitor.get_weekly_usage(start_date))

        @self.app.route("/api/energy/savings")
        def api_energy_savings():
            """Get energy savings analysis"""
            days = request.args.get("days", 30, type=int)
            return jsonify(self.energy_monitor.calculate_energy_savings(days))

        @self.app.route("/api/energy/patterns")
        def api_energy_patterns():
            """Get usage patterns"""
            days = request.args.get("days", 7, type=int)
            return jsonify(self.energy_monitor.get_usage_patterns(days))

        @self.app.route("/api/monitor/live")
        def api_monitor_live():
            """Get live monitoring data for real-time dashboard"""
            if not self.all_systems_ready():
                return jsonify({"error": "Systems not initialized"}), 503

            # Get current detections and system status
            camera_status = self.camera_system.get_current_status()
            detections = camera_status.get("detections", [])

            # Get zone occupancy
            zone_occupancy = self.zone_manager.update_occupancy(detections)
            all_zones = self.zone_manager.get_all_zones()

            # Get lighting status
            all_lights = self.lighting_system.get_all_lights()

            # Compile comprehensive monitoring data
            monitoring_data = {
                "timestamp": datetime.now().isoformat(),
                "system_health": {
                    "main_loop_running": self.running
                    and self.main_loop_thread
                    and self.main_loop_thread.is_alive(),
                    "camera_active": camera_status.get("has_frame", False),
                    "total_detections": len(detections),
                    "systems_ready": self.all_systems_ready(),
                },
                "detections": {"count": len(detections), "people": detections},
                "zones": {
                    "occupancy": zone_occupancy,
                    "details": {
                        zone_id: {
                            "name": zone.name,
                            "current_occupancy": zone.current_occupancy,
                            "last_occupied": (
                                zone.last_occupied.isoformat()
                                if zone.last_occupied
                                else None
                            ),
                            "enabled": zone.enabled,
                        }
                        for zone_id, zone in all_zones.items()
                    },
                },
                "lights": {
                    "summary": {
                        "total": len(all_lights),
                        "on": sum(1 for light in all_lights.values() if light.is_on),
                        "off": sum(
                            1 for light in all_lights.values() if not light.is_on
                        ),
                    },
                    "details": {
                        light_id: {
                            "name": light.name,
                            "is_on": light.is_on,
                            # 'brightness' removed
                            "power_watts": light.power_watts,
                            "manual_override": light.manual_override,
                            "zone_ids": light.zone_ids,
                        }
                        for light_id, light in all_lights.items()
                    },
                },
                "energy": {
                    "current_power": self.energy_monitor.get_current_power_consumption(),
                    "today_usage": self.energy_monitor.get_daily_usage(),
                    "currency": self.energy_monitor.currency,
                },
            }

            return jsonify(monitoring_data)

        @self.app.route("/video_feed")
        def video_feed():
            """Video streaming route"""
            return Response(
                self.generate_video_feed(),
                mimetype="multipart/x-mixed-replace; boundary=frame",
            )

    def setup_socket_events(self):
        """Setup SocketIO event handlers"""

        @self.socketio.on("connect")
        def handle_connect():
            logger.info(f"Client connected: {request.sid}")
            # Start main loop when first client connects
            if not (
                self.running
                and self.main_loop_thread
                and self.main_loop_thread.is_alive()
            ):
                self.start_main_loop()
            emit("status", {"connected": True})

        @self.socketio.on("disconnect")
        def handle_disconnect():
            logger.info(f"Client disconnected: {request.sid}")

        @self.socketio.on("request_update")
        def handle_request_update():
            """Send real-time updates to client"""
            if self.all_systems_ready():
                self.emit_system_update()

    def generate_video_feed(self):
        """Generate video feed for streaming"""
        while True:
            if self.camera_system:
                frame = self.camera_system.get_frame_with_detections()
                if frame is not None:
                    # Draw zones on frame
                    frame = self.zone_manager.draw_zones(frame, show_occupancy=True)

                    # Resize for streaming
                    frame = resize_frame_for_web(frame, 640)

                    # Encode frame
                    frame_bytes = encode_frame_to_jpeg(frame, quality=60)

                    yield (
                        b"--frame\r\n"
                        b"Content-Type: image/jpeg\r\n\r\n" + frame_bytes + b"\r\n"
                    )
                else:
                    time.sleep(0.1)
            else:
                time.sleep(1)

    def main_loop(self):
        """Main application loop for real-time lighting control"""
        logger.info("Entering main lighting control loop")
        iteration = 0

        while self.running:
            try:
                iteration += 1

                if iteration % 120 == 0:  # Log every 60 seconds for system health
                    logger.info(
                        f"Main loop iteration {iteration} - Systems running normally"
                    )

                # Check if we should exit due to system readiness
                if not self.all_systems_ready():
                    logger.warning("Systems not ready, exiting main loop")
                    break

                # Get current detections
                detections = self.camera_system.get_current_status()["detections"]

                # Update zone occupancy
                zone_occupancy = self.zone_manager.update_occupancy(detections)

                # Update lighting based on occupancy
                lighting_results = self.lighting_system.update_zone_lighting(
                    zone_occupancy
                )

                # Record energy events for changed lights (no logging)
                for zone_id, controlled_lights in lighting_results.items():
                    for light_id in controlled_lights:
                        light = self.lighting_system.get_light(light_id)
                        if light:
                            self.energy_monitor.record_light_event(
                                light_id=light_id,
                                light_name=light.name,
                                event="on" if light.is_on else "off",
                                power_watts=light.power_watts,
                                # brightness removed
                            )
                            # Save a capture showing the change and log it
                            try:
                                frame_for_log = self.camera_system.get_clean_frame()
                                human_count = len(detections) if detections is not None else 0
                                saved = save_frame_and_log(
                                    frame_for_log, light_id, zone_id, human_count
                                )
                                if saved:
                                    logger.debug(f"Logged capture for {light_id} -> {saved}")
                            except Exception as e:
                                logger.warning(f"Failed to save/log capture for {light_id}: {e}")

                # Emit updates via SocketIO for web interface
                current_time = time.time()
                if (
                    current_time - self.last_update_time > 1
                ):  # Update every 1 second for web
                    self.emit_system_update()
                    self.last_update_time = current_time

                time.sleep(0.5)  # Main loop frequency

            except Exception as e:
                import traceback

                logger.error(f"Error in main loop iteration {iteration}: {e}")
                logger.error(f"Exception type: {type(e).__name__}")
                logger.error(f"Full traceback:\n{traceback.format_exc()}")
                time.sleep(1)

        logger.info("Main loop exited - self.running = " + str(self.running))

    def emit_system_update(self):
        """Emit real-time system updates via SocketIO"""
        try:
            if not self.all_systems_ready():
                return

            # Get current camera status and detections
            camera_status = self.camera_system.get_current_status()
            detections = camera_status.get("detections", [])

            # Get zone data and calculate summary stats
            all_zones = self.zone_manager.get_all_zones()
            active_zones = sum(
                1 for zone in all_zones.values() if zone.current_occupancy > 0
            )
            total_people = sum(zone.current_occupancy for zone in all_zones.values())

            # Get lighting data and calculate summary stats
            all_lights = self.lighting_system.get_all_lights()
            lights_on = sum(1 for light in all_lights.values() if light.is_on)

            # Simple update data without problematic datetime formatting
            update_data = {
                "timestamp": datetime.now().isoformat(),
                "system_health": {
                    "main_loop_running": self.running
                    and self.main_loop_thread
                    and self.main_loop_thread.is_alive(),
                    "camera_active": camera_status.get("has_frame", False),
                    "total_detections": len(detections),
                    "systems_ready": self.all_systems_ready(),
                },
                "detections": {"count": len(detections), "people": detections},
                "zones": {
                    "total_zones": len(all_zones),
                    "active_zones": active_zones,
                    "total_people": total_people,
                    "zone_data": {
                        zone_id: {
                            "name": zone.name,
                            "occupancy": zone.current_occupancy,
                            "last_occupied": (
                                str(zone.last_occupied) if zone.last_occupied else None
                            ),
                            "enabled": zone.enabled,
                        }
                        for zone_id, zone in all_zones.items()
                    },
                },
                "lights": {
                    "total_lights": len(all_lights),
                    "lights_on": lights_on,
                    "lights_off": len(all_lights) - lights_on,
                    "light_data": {
                        light_id: {
                            "name": light.name,
                            "is_on": light.is_on,
                            # 'brightness' removed
                            "power_watts": light.power_watts,
                            "manual_override": light.manual_override,
                            "zone_ids": light.zone_ids,
                        }
                        for light_id, light in all_lights.items()
                    },
                },
                "camera": {
                    "human_count": camera_status.get("human_count", 0),
                    "has_frame": camera_status.get("has_frame", False),
                    "detections": detections,
                },
                "energy": {
                    "current_power": self.energy_monitor.get_current_power_consumption(),
                    "daily_usage": self.energy_monitor.get_daily_usage(),
                    "savings": self.energy_monitor.calculate_energy_savings(1),
                    "currency": self.energy_monitor.currency,
                },
            }

            # Emit general system update
            self.socketio.emit("system_update", update_data)

            # Emit specific monitoring data for real-time dashboard
            self.socketio.emit(
                "monitor_update",
                {
                    "detections": len(detections),
                    "zones_occupied": active_zones,
                    "lights_on": lights_on,
                    "power_consumption": self.energy_monitor.get_current_power_consumption(),
                    "timestamp": datetime.now().isoformat(),
                    "detailed_zones": {
                        zone_id: {
                            "name": zone.name,
                            "occupancy": zone.current_occupancy,
                            "status": (
                                "occupied" if zone.current_occupancy > 0 else "empty"
                            ),
                        }
                        for zone_id, zone in all_zones.items()
                    },
                    "detailed_lights": {
                        light_id: {
                            "name": light.name,
                            "status": "on" if light.is_on else "off",
                            "power": light.power_watts if light.is_on else 0,
                        }
                        for light_id, light in all_lights.items()
                    },
                },
            )

        except Exception as e:
            logger.error(f"Error emitting system update: {e}")
            import traceback

            logger.error(f"Full traceback: {traceback.format_exc()}")

    def all_systems_ready(self) -> bool:
        """Check if all systems are initialized and ready"""
        return all(
            [
                self.camera_system is not None,
                self.zone_manager is not None,
                self.lighting_system is not None,
                self.energy_monitor is not None,
            ]
        )

    def run(self, host: str = None, port: int = None, debug: bool = False):
        """Run the application"""
        try:
            # Initialize all systems
            self.initialize_systems()

            # Get server config
            server_config = self.config.get("server", {})
            host = host or server_config.get("host", "0.0.0.0")
            port = port or server_config.get("port", 5000)
            debug = debug or server_config.get("debug", False)

            logger.info(f"Starting Smart Lighting System on {host}:{port}")

            # Explicitly start the main loop before starting the server
            self.start_main_loop()

            # Run the Flask-SocketIO server
            logger.info(f"Starting SocketIO server on {host}:{port}")
            self.socketio.run(self.app, host=host, port=port, debug=debug)

        except KeyboardInterrupt:
            logger.info("Shutting down...")
        except Exception as e:
            import traceback

            logger.error(f"Application error: {e}")
            logger.error(f"Full traceback:\n{traceback.format_exc()}")
        finally:
            self.cleanup()

    def cleanup(self):
        """Cleanup resources"""
        logger.info("Cleaning up resources...")
        self.running = False

        if self.camera_system:
            self.camera_system.stop()

        # Wait for main loop to finish
        if self.main_loop_thread and self.main_loop_thread.is_alive():
            self.main_loop_thread.join(timeout=5)

        if self.lighting_system:
            self.lighting_system.cleanup()

        if self.energy_monitor:
            self.energy_monitor.cleanup()

        logger.info("Cleanup completed")


# Create the main application instance
def create_app(config_file: str = "config.json"):
    """Create and configure the Flask application"""
    return SmartLightingApp(config_file)


if __name__ == "__main__":
    app = create_app()
    app.run()
