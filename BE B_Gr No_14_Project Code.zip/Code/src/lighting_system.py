import json
import logging
import os
import platform
import threading
import time
from datetime import datetime
from typing import Dict, List, Optional, Union

# Platform-specific imports with safer detection for Raspberry Pi 5
GPIO_AVAILABLE = False
GPIO = None
LED = None
PWMOutputDevice = None
try:
    # Try to import RPi.GPIO first
    import RPi.GPIO as GPIO

    GPIO_AVAILABLE = True
except Exception:
    GPIO = None

try:
    # Prefer gpiozero and pigpio for better PWM support on newer Pi hardware
    import gpiozero

    try:
        # Attempt to use pigpio factory if available (recommended on Pi 5)
        # PWMOutputDevice moved/abstracted; use PWMLED as a better abstraction when needed
        from gpiozero import LED
        from gpiozero import PWMLED as PWMOutputDevice
        from gpiozero.pins.pigpio import PiGPIOFactory

        GPIO_AVAILABLE = GPIO_AVAILABLE or True
    except Exception:
        # Fallback to default gpiozero devices
        from gpiozero import LED
        from gpiozero import PWMLED as PWMOutputDevice  # type: ignore

        GPIO_AVAILABLE = GPIO_AVAILABLE or True
except Exception:
    # gpiozero not available
    LED = None
    PWMOutputDevice = None

logger = logging.getLogger(__name__)


class Light:
    """Represents a single controllable light"""

    def __init__(
        self,
        light_id: str,
        name: str,
        pin: int = None,
        power_watts: float = 15.0,
        zone_ids: List[str] = None,
    ):
        self.id = light_id
        self.name = name
        self.pin = pin
        self.power_watts = power_watts
        self.zone_ids = zone_ids or []

        # State
        self.is_on = False
        self.manual_override = False
        self.last_toggled = None

        # Usage tracking
        self.total_on_time = 0  # seconds
        self.daily_on_time = 0  # seconds today
        self.last_reset_date = datetime.now().date()

        # Hardware interface
        self.gpio_device = None
        self._lock = threading.Lock()

    def to_dict(self) -> dict:
        """Convert light to dictionary for serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "pin": self.pin,
            "power_watts": self.power_watts,
            "zone_ids": self.zone_ids,
            "is_on": self.is_on,
            "manual_override": self.manual_override,
            "last_toggled": self.last_toggled,
            "total_on_time": self.total_on_time,
            "daily_on_time": self.daily_on_time,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Light":
        """Create light from dictionary"""
        light = cls(
            light_id=data["id"],
            name=data["name"],
            pin=data.get("pin"),
            power_watts=data.get("power_watts", 15.0),
            zone_ids=data.get("zone_ids", []),
        )
        light.is_on = data.get("is_on", False)
        light.manual_override = data.get("manual_override", False)
        light.last_toggled = data.get("last_toggled")
        light.total_on_time = data.get("total_on_time", 0)
        light.daily_on_time = data.get("daily_on_time", 0)
        return light

    def reset_daily_stats(self):
        """Reset daily statistics"""
        today = datetime.now().date()
        if today > self.last_reset_date:
            self.daily_on_time = 0
            self.last_reset_date = today


class GPIOLightController:
    """GPIO-based light controller for Raspberry Pi"""

    def __init__(self, config: dict):
        self.config = config
        self.active_low = config.get("relay_active_low", True)
        self.lights: Dict[str, Light] = {}
        self.gpio_devices: Dict[int, object] = {}
        # Use pigpio factory if available and configured
        self._gpio_factory = None
        if "gpio_factory" in config and config.get("gpio_factory") == "pigpio":
            try:
                from gpiozero.pins.pigpio import PiGPIOFactory

                self._gpio_factory = PiGPIOFactory()
                logger.info("Using PiGPIOFactory for gpiozero")
            except Exception:
                logger.warning(
                    "PiGPIOFactory requested but not available; falling back to default"
                )

        if not GPIO_AVAILABLE:
            raise RuntimeError("GPIO not available - not running on Raspberry Pi?")

        # Initialize GPIO
        try:
            # Only setmode if RPi.GPIO is present
            if GPIO is not None:
                GPIO.setmode(GPIO.BCM)
                logger.info("RPi.GPIO set to BCM mode")
            logger.info("GPIO initialization complete for lighting control")
        except Exception as e:
            logger.error(f"Failed to initialize GPIO: {e}")
            raise

    def add_light(self, light: Light) -> bool:
        """Add a light to GPIO control"""
        if light.pin is None:
            logger.error(f"Light {light.name} has no pin assigned")
            return False

        try:
            # Create GPIO device based on whether we need PWM
            # The system no longer supports dimming; use simple LED/relay control
            if LED is None:
                raise RuntimeError("gpiozero LED device not available")
            if self._gpio_factory is not None:
                device = LED(
                    light.pin,
                    active_high=not self.active_low,
                    pin_factory=self._gpio_factory,
                )
            else:
                device = LED(light.pin, active_high=not self.active_low)

            self.gpio_devices[light.pin] = device
            self.lights[light.id] = light
            light.gpio_device = device

            logger.info(f"Added light '{light.name}' on GPIO pin {light.pin}")
            return True

        except Exception as e:
            logger.error(f"Failed to add light '{light.name}': {e}")
            return False

    def remove_light(self, light_id: str) -> bool:
        """Remove a light from GPIO control"""
        if light_id not in self.lights:
            return False

        light = self.lights[light_id]

        try:
            if light.pin in self.gpio_devices:
                self.gpio_devices[light.pin].close()
                del self.gpio_devices[light.pin]

            del self.lights[light_id]
            light.gpio_device = None

            logger.info(f"Removed light '{light.name}'")
            return True

        except Exception as e:
            logger.error(f"Failed to remove light '{light.name}': {e}")
            return False

    def set_light_state(self, light_id: str, state: bool) -> bool:
        """Set light state (no brightness)"""
        if light_id not in self.lights:
            return False
        light = self.lights[light_id]
        try:
            with light._lock:
                light.is_on = state
                light.last_toggled = datetime.now().isoformat()
                # Control GPIO device
                if light.gpio_device:
                    if state:
                        light.gpio_device.on()
                    else:
                        light.gpio_device.off()
            logger.debug(f"Set light '{light.name}' to {'ON' if state else 'OFF'}")
            return True
        except Exception as e:
            logger.error(f"Failed to control light '{light.name}': {e}")
            return False

    def cleanup(self):
        """Clean up GPIO resources"""
        try:
            for device in self.gpio_devices.values():
                device.close()
            self.gpio_devices.clear()
            GPIO.cleanup()
            logger.info("GPIO cleanup completed")
        except Exception as e:
            logger.error(f"GPIO cleanup error: {e}")





class LightingSystem:
    """Main lighting control system"""

    def __init__(self, config: dict):
        self.config = config
        self.platform = config.get("platform", "raspberry_pi")
        # default_brightness not used anymore
        self.default_brightness = None

        # Initialize GPIO controller (required)
        if not GPIO_AVAILABLE:
            raise RuntimeError(
                "GPIO not available. This system requires Raspberry Pi with GPIO support. "
                "Install: sudo apt install python3-rpi.gpio python3-gpiozero"
            )
        
        self.controller = GPIOLightController(config)
        logger.info("Using GPIO lighting controller")

        self.lights: Dict[str, Light] = {}
        self.auto_control_enabled = True
        self.manual_overrides: Dict[str, bool] = {}

        # Usage tracking
        self.usage_tracker = threading.Thread(
            target=self._usage_tracking_loop, daemon=True
        )
        self.running = True
        self.usage_tracker.start()

        # Load existing lights
        self.load_lights()

    def create_light(
        self,
        name: str,
        pin: int = None,
        power_watts: float = 15.0,
        zone_ids: List[str] = None,
    ) -> str:
        """Create a new light"""
        import uuid

        light_id = str(uuid.uuid4())

        light = Light(light_id, name, pin, power_watts, zone_ids)

        if self.controller.add_light(light):
            self.lights[light_id] = light
            self.save_lights()
            logger.info(f"Created light '{name}' with ID {light_id}")
            return light_id
        else:
            raise RuntimeError(f"Failed to create light '{name}'")

    def register_light(self, light_id: str, name: str, pin: int = None, power_watts: float = 15.0, zone_ids: List[str] = None) -> bool:
        """Register an existing light id into the system (used when loading zones that contain light_ids)

        This will create a Light object with the provided id and attempt to add it to the GPIO controller.
        Returns True on success.
        """
        light = Light(light_id, name, pin, power_watts, zone_ids)
        if self.controller.add_light(light):
            self.lights[light_id] = light
            self.save_lights()
            logger.info(f"Registered light '{name}' with ID {light_id} on pin {pin}")
            return True
        else:
            logger.error(f"Failed to register light {name} ({light_id}) on pin {pin})")
            return False

    def update_light(
        self,
        light_id: str,
        name: str = None,
        pin: int = None,
        power_watts: float = None,
        zone_ids: List[str] = None,
    ) -> bool:
        """Update an existing light"""
        if light_id not in self.lights:
            return False

        light = self.lights[light_id]

        # Update properties
        if name is not None:
            light.name = name
        if pin is not None and pin != light.pin:
            # Remove from old pin and add to new pin
            self.controller.remove_light(light_id)
            light.pin = pin
            self.controller.add_light(light)
        if power_watts is not None:
            light.power_watts = power_watts
        if zone_ids is not None:
            light.zone_ids = zone_ids

        self.save_lights()
        return True

    def delete_light(self, light_id: str) -> bool:
        """Delete a light"""
        if light_id not in self.lights:
            return False

        light = self.lights[light_id]
        self.controller.remove_light(light_id)
        del self.lights[light_id]

        # Remove from manual overrides
        if light_id in self.manual_overrides:
            del self.manual_overrides[light_id]

        self.save_lights()
        logger.info(f"Deleted light '{light.name}'")
        return True

    def get_light(self, light_id: str) -> Optional[Light]:
        """Get a specific light"""
        return self.lights.get(light_id)

    def get_all_lights(self) -> Dict[str, Light]:
        """Get all lights"""
        return self.lights.copy()

    def control_light(self, light_id: str, state: bool, manual: bool = False) -> bool:
        """Control a light manually or automatically"""
        if light_id not in self.lights:
            return False
        light = self.lights[light_id]
        # Set manual override flag
        if manual:
            self.manual_overrides[light_id] = True
            light.manual_override = True
        if light.is_on == state:
            return True
        return self.controller.set_light_state(light_id, state)

    def control_zone_lights(self, zone_id: str, occupied: bool) -> List[str]:
        """Control all lights in a zone based on occupancy"""
        controlled_lights = []
        for light_id, light in self.lights.items():
            # Skip if manual override is active
            if self.manual_overrides.get(light_id, False):
                continue
            # Check if light belongs to this zone
            if zone_id in light.zone_ids:
                if light.is_on != occupied:
                    if self.controller.set_light_state(light_id, occupied):
                        controlled_lights.append(light_id)
        return controlled_lights

    def update_zone_lighting(
        self, zone_occupancy: Dict[str, int]
    ) -> Dict[str, List[str]]:
        """Update lighting based on zone occupancy"""
        results = {}

        for zone_id, occupancy_count in zone_occupancy.items():
            occupied = occupancy_count > 0
            controlled_lights = self.control_zone_lights(zone_id, occupied)
            results[zone_id] = controlled_lights

        return results

    def clear_manual_override(self, light_id: str) -> bool:
        """Clear manual override for a light"""
        if light_id in self.lights:
            self.manual_overrides[light_id] = False
            self.lights[light_id].manual_override = False
            return True
        return False

    def clear_all_manual_overrides(self):
        """Clear all manual overrides"""
        for light_id in self.lights:
            self.manual_overrides[light_id] = False
            self.lights[light_id].manual_override = False
        logger.info("Cleared all manual overrides")

    def set_auto_control(self, enabled: bool):
        """Enable or disable automatic control"""
        self.auto_control_enabled = enabled
        logger.info(f"Automatic control {'enabled' if enabled else 'disabled'}")

    def get_system_status(self) -> dict:
        """Get current system status"""
        total_lights = len(self.lights)
        lights_on = sum(1 for light in self.lights.values() if light.is_on)
        manual_overrides = sum(
            1 for override in self.manual_overrides.values() if override
        )
        total_power = sum(
            light.power_watts for light in self.lights.values() if light.is_on
        )

        return {
            "total_lights": total_lights,
            "lights_on": lights_on,
            "lights_off": total_lights - lights_on,
            "manual_overrides": manual_overrides,
            "auto_control_enabled": self.auto_control_enabled,
            "current_power_watts": total_power,
            "platform": self.platform,
        }

    def _usage_tracking_loop(self):
        """Background thread for tracking usage time"""
        while self.running:
            current_time = time.time()

            for light in self.lights.values():
                if light.is_on:
                    # Reset daily stats if needed
                    light.reset_daily_stats()

                    # Add one second to usage counters
                    light.total_on_time += 1
                    light.daily_on_time += 1

            time.sleep(1)  # Update every second

    def save_lights(self, filename: str = "data/lights.json"):
        """Save lights configuration"""
        try:
            os.makedirs(os.path.dirname(filename), exist_ok=True)

            data = {
                "lights": {
                    light_id: light.to_dict() for light_id, light in self.lights.items()
                },
                "manual_overrides": self.manual_overrides,
                "auto_control_enabled": self.auto_control_enabled,
                "saved_at": datetime.now().isoformat(),
            }

            with open(filename, "w") as f:
                json.dump(data, f, indent=2)

            logger.info(f"Saved {len(self.lights)} lights to {filename}")

        except Exception as e:
            logger.error(f"Failed to save lights: {e}")

    def load_lights(self, filename: str = "data/lights.json"):
        """Load lights configuration"""
        if not os.path.exists(filename):
            logger.info(f"No existing lights file found at {filename}")
            return

        try:
            with open(filename, "r") as f:
                data = json.load(f)

            # Load lights
            lights_data = data.get("lights", {})
            self.lights = {}

            # Assign missing pins using config order to keep mapping stable
            gpio_pins = self.config.get("gpio_pins", []) or []
            used_pins = {light_data.get("pin") for light_data in lights_data.values()}
            used_pins.discard(None)
            available_pins = [pin for pin in gpio_pins if pin not in used_pins]
            needs_pin = [
                (light_id, light_data)
                for light_id, light_data in lights_data.items()
                if light_data.get("pin") is None
            ]
            needs_pin.sort(
                key=lambda item: (item[1].get("name") or "", item[0])
            )
            pins_assigned = False
            for light_id, light_data in needs_pin:
                if not available_pins:
                    break
                light_data["pin"] = available_pins.pop(0)
                pins_assigned = True
                logger.info(
                    "Assigned GPIO pin %s to light '%s' (%s)",
                    light_data["pin"],
                    light_data.get("name") or light_id,
                    light_id,
                )

            for light_id, light_data in lights_data.items():
                light = Light.from_dict(light_data)
                self.lights[light_id] = light
                if light.pin is None:
                    logger.warning(
                        "Light '%s' (%s) has no GPIO pin; skipping hardware registration",
                        light.name,
                        light_id,
                    )
                    continue
                self.controller.add_light(light)

            # Load settings
            self.manual_overrides = data.get("manual_overrides", {})
            self.auto_control_enabled = data.get("auto_control_enabled", True)

            # Update manual override flags
            for light_id, override in self.manual_overrides.items():
                if light_id in self.lights:
                    self.lights[light_id].manual_override = override

            if pins_assigned:
                self.save_lights(filename)

            logger.info(f"Loaded {len(self.lights)} lights from {filename}")

        except Exception as e:
            logger.error(f"Failed to load lights: {e}")

    def cleanup(self):
        """Clean up resources"""
        self.running = False
        if hasattr(self, "usage_tracker"):
            self.usage_tracker.join(timeout=2)

        self.save_lights()
        self.controller.cleanup()
        logger.info("Lighting system cleanup completed")
