import json
import logging
import os
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)


class Zone:
    """Represents a lighting control zone"""

    def __init__(
        self,
        zone_id: str,
        name: str,
        points: List[Tuple[int, int]],
        light_ids: List[str] = None,
        enabled: bool = True,
    ):
        self.id = zone_id
        self.name = name
        # Convert points to integers to handle float coordinates from frontend
        self.points = [(int(p[0]), int(p[1])) for p in points]
        self.light_ids = light_ids or []
        self.enabled = enabled
        self.created_at = datetime.now().isoformat()
        self.last_occupied = None
        self.current_occupancy = 0

        # Create polygon mask for efficient point-in-polygon checks
        self._update_mask()

    def _update_mask(self):
        """Update the polygon mask for occupancy detection"""
        if len(self.points) < 3:
            self.mask = None
            return

        # Points are already integers from constructor/update
        # Find bounding box
        xs = [p[0] for p in self.points]
        ys = [p[1] for p in self.points]
        self.bbox = (min(xs), min(ys), max(xs), max(ys))

        # Create mask
        mask_width = max(xs) - min(xs) + 1
        mask_height = max(ys) - min(ys) + 1

        if mask_width > 0 and mask_height > 0:
            # Adjust points relative to bounding box
            adjusted_points = [(x - min(xs), y - min(ys)) for x, y in self.points]

            self.mask = np.zeros((mask_height, mask_width), dtype=np.uint8)
            cv2.fillPoly(self.mask, [np.array(adjusted_points, dtype=np.int32)], 255)
        else:
            self.mask = None

    def contains_point(self, x: int, y: int) -> bool:
        """Check if a point is inside this zone"""
        if self.mask is None or len(self.points) < 3:
            return False

        # Check if point is within bounding box first
        min_x, min_y, max_x, max_y = self.bbox
        if not (min_x <= x <= max_x and min_y <= y <= max_y):
            return False

        # Check against mask
        mask_x = x - min_x
        mask_y = y - min_y

        if 0 <= mask_x < self.mask.shape[1] and 0 <= mask_y < self.mask.shape[0]:
            return self.mask[mask_y, mask_x] > 0

        return False

    def check_occupancy(
        self, detections: List[Tuple[int, int, int, int, float]]
    ) -> int:
        """Check how many people are in this zone"""
        if not self.enabled:
            return 0

        count = 0
        for x1, y1, x2, y2, conf in detections:
            # Use center point of detection box
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2

            if self.contains_point(center_x, center_y):
                count += 1

        self.current_occupancy = count
        if count > 0:
            self.last_occupied = datetime.now().isoformat()

        return count

    def to_dict(self) -> dict:
        """Convert zone to dictionary for serialization"""
        return {
            "id": self.id,
            "name": self.name,
            "points": self.points,
            "light_ids": self.light_ids,
            "enabled": self.enabled,
            "created_at": self.created_at,
            "last_occupied": self.last_occupied,
            "current_occupancy": self.current_occupancy,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Zone":
        """Create zone from dictionary"""
        zone = cls(
            zone_id=data["id"],
            name=data["name"],
            points=data["points"],
            light_ids=data.get("light_ids", []),
            enabled=data.get("enabled", True),
        )
        zone.created_at = data.get("created_at", datetime.now().isoformat())
        zone.last_occupied = data.get("last_occupied")
        zone.current_occupancy = data.get("current_occupancy", 0)
        return zone


class ZoneManager:
    """Manages all lighting zones"""

    def __init__(self, config: dict):
        self.config = config
        self.zones: Dict[str, Zone] = {}
        self.save_file = config.get("save_file", "zones.json")
        self.auto_save = config.get("auto_save", True)

        # Reference frame for zone definition
        self.reference_frame = None
        self.reference_timestamp = None

        # Load existing zones
        self.load_zones()

    def set_reference_frame(self, frame: np.ndarray):
        """Set the reference frame for zone definition"""
        self.reference_frame = frame.copy()
        self.reference_timestamp = datetime.now().isoformat()
        logger.info("Reference frame updated")

    def get_reference_frame(self) -> Optional[np.ndarray]:
        """Get the current reference frame"""
        return self.reference_frame.copy() if self.reference_frame is not None else None

    def create_zone(
        self, name: str, points: List[Tuple[int, int]], light_ids: List[str] = None
    ) -> str:
        """Create a new zone"""
        if len(points) < 3:
            raise ValueError("Zone must have at least 3 points")

        zone_id = str(uuid.uuid4())
        zone = Zone(zone_id, name, points, light_ids)
        self.zones[zone_id] = zone

        if self.auto_save:
            self.save_zones()

        logger.info(f"Created zone '{name}' with {len(points)} points")
        return zone_id

    def update_zone(
        self,
        zone_id: str,
        name: str = None,
        points: List[Tuple[int, int]] = None,
        light_ids: List[str] = None,
        enabled: bool = None,
    ) -> bool:
        """Update an existing zone"""
        if zone_id not in self.zones:
            return False

        zone = self.zones[zone_id]

        if name is not None:
            zone.name = name
        if points is not None:
            if len(points) < 3:
                raise ValueError("Zone must have at least 3 points")
            # Convert points to integers to handle float coordinates from frontend
            zone.points = [(int(p[0]), int(p[1])) for p in points]
            zone._update_mask()
        if light_ids is not None:
            zone.light_ids = light_ids
        if enabled is not None:
            zone.enabled = enabled

        if self.auto_save:
            self.save_zones()

        logger.info(f"Updated zone '{zone.name}'")
        return True

    def delete_zone(self, zone_id: str) -> bool:
        """Delete a zone"""
        if zone_id not in self.zones:
            return False

        zone_name = self.zones[zone_id].name
        del self.zones[zone_id]

        if self.auto_save:
            self.save_zones()

        logger.info(f"Deleted zone '{zone_name}'")
        return True

    def get_zone(self, zone_id: str) -> Optional[Zone]:
        """Get a specific zone"""
        return self.zones.get(zone_id)

    def get_all_zones(self) -> Dict[str, Zone]:
        """Get all zones"""
        return self.zones.copy()

    def update_occupancy(
        self, detections: List[Tuple[int, int, int, int, float]]
    ) -> Dict[str, int]:
        """Update occupancy for all zones"""
        occupancy = {}

        for zone_id, zone in self.zones.items():
            count = zone.check_occupancy(detections)
            occupancy[zone_id] = count

        return occupancy

    def get_occupied_zones(self) -> List[str]:
        """Get list of currently occupied zone IDs"""
        return [
            zone_id
            for zone_id, zone in self.zones.items()
            if zone.enabled and zone.current_occupancy > 0
        ]

    def save_zones(self, filename: str = None):
        """Save zones to file"""
        filename = filename or self.save_file

        try:
            # Ensure data directory exists
            os.makedirs(
                os.path.dirname(filename) if os.path.dirname(filename) else "data",
                exist_ok=True,
            )

            # Prepare data for saving
            data = {
                "zones": {
                    zone_id: zone.to_dict() for zone_id, zone in self.zones.items()
                },
                "reference_timestamp": self.reference_timestamp,
                "saved_at": datetime.now().isoformat(),
            }

            with open(filename, "w") as f:
                json.dump(data, f, indent=2)

            logger.info(f"Saved {len(self.zones)} zones to {filename}")

        except Exception as e:
            logger.error(f"Failed to save zones: {e}")

    def load_zones(self, filename: str = None):
        """Load zones from file"""
        filename = filename or self.save_file

        if not os.path.exists(filename):
            logger.info(f"No existing zones file found at {filename}")
            return

        try:
            with open(filename, "r") as f:
                data = json.load(f)

            # Load zones
            zones_data = data.get("zones", {})
            self.zones = {}

            for zone_id, zone_data in zones_data.items():
                self.zones[zone_id] = Zone.from_dict(zone_data)

            self.reference_timestamp = data.get("reference_timestamp")

            logger.info(f"Loaded {len(self.zones)} zones from {filename}")

        except Exception as e:
            logger.error(f"Failed to load zones: {e}")

    def draw_zones(
        self, frame: np.ndarray, show_occupancy: bool = True, show_labels: bool = True
    ) -> np.ndarray:
        """Draw all zones on a frame"""
        if frame is None:
            return None

        result = frame.copy()

        for zone in self.zones.values():
            if len(zone.points) < 3:
                continue

            # Choose color based on occupancy and enabled state
            if not zone.enabled:
                color = (128, 128, 128)  # Gray for disabled
            elif zone.current_occupancy > 0:
                color = (0, 255, 0)  # Green for occupied
            else:
                color = (0, 0, 255)  # Red for empty

            # Draw zone polygon
            points = np.array(zone.points, dtype=np.int32)
            cv2.polylines(result, [points], True, color, 2)

            # Fill with transparent color
            overlay = result.copy()
            alpha = 0.2
            cv2.fillPoly(overlay, [points], color)
            cv2.addWeighted(result, 1 - alpha, overlay, alpha, 0, result)

            if show_labels:
                # Draw zone label
                center_x = sum(p[0] for p in zone.points) // len(zone.points)
                center_y = sum(p[1] for p in zone.points) // len(zone.points)

                label = zone.name
                if show_occupancy:
                    label += f" ({zone.current_occupancy})"

                # Add background for text
                text_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
                cv2.rectangle(
                    result,
                    (center_x - text_size[0] // 2 - 5, center_y - text_size[1] - 5),
                    (center_x + text_size[0] // 2 + 5, center_y + 5),
                    (0, 0, 0),
                    -1,
                )

                cv2.putText(
                    result,
                    label,
                    (center_x - text_size[0] // 2, center_y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (255, 255, 255),
                    2,
                )

        return result

    def get_zone_statistics(self) -> dict:
        """Get statistics about all zones"""
        total_zones = len(self.zones)
        enabled_zones = sum(1 for zone in self.zones.values() if zone.enabled)
        occupied_zones = sum(
            1 for zone in self.zones.values() if zone.current_occupancy > 0
        )
        total_occupancy = sum(zone.current_occupancy for zone in self.zones.values())

        return {
            "total_zones": total_zones,
            "enabled_zones": enabled_zones,
            "occupied_zones": occupied_zones,
            "total_occupancy": total_occupancy,
            "occupancy_rate": occupied_zones / max(enabled_zones, 1),
        }


# Utility functions for zone manipulation
def simplify_polygon(
    points: List[Tuple[int, int]], tolerance: float = 2.0
) -> List[Tuple[int, int]]:
    """Simplify polygon using Douglas-Peucker algorithm"""
    if len(points) <= 3:
        return points

    def distance_point_to_line(point, line_start, line_end):
        """Calculate perpendicular distance from point to line"""
        x0, y0 = point
        x1, y1 = line_start
        x2, y2 = line_end

        if x1 == x2 and y1 == y2:
            return np.sqrt((x0 - x1) ** 2 + (y0 - y1) ** 2)

        return abs((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1) / np.sqrt(
            (y2 - y1) ** 2 + (x2 - x1) ** 2
        )

    def douglas_peucker(points, tolerance):
        if len(points) <= 2:
            return points

        # Find the point with maximum distance from line
        max_distance = 0
        max_index = 0

        for i in range(1, len(points) - 1):
            distance = distance_point_to_line(points[i], points[0], points[-1])
            if distance > max_distance:
                max_distance = distance
                max_index = i

        # If max distance is greater than tolerance, recursively simplify
        if max_distance > tolerance:
            # Recursive call
            left_points = douglas_peucker(points[: max_index + 1], tolerance)
            right_points = douglas_peucker(points[max_index:], tolerance)

            # Combine results
            return left_points[:-1] + right_points
        else:
            return [points[0], points[-1]]

    # Close the polygon if not already closed
    if points[0] != points[-1]:
        points = points + [points[0]]

    simplified = douglas_peucker(points, tolerance)

    # Remove the duplicate closing point
    if len(simplified) > 1 and simplified[0] == simplified[-1]:
        simplified = simplified[:-1]

    return simplified
