import csv
import os
from datetime import datetime
from typing import Optional

import cv2
import numpy as np


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def save_frame_and_log(
    frame: np.ndarray,
    light_id: str,
    zone_id: str,
    human_count: int,
    out_dir: str = "data/captures",
    csv_file: str = "data/capture_log.csv",
) -> Optional[str]:
    """Save frame to disk and append a log row to CSV.

    Returns the saved image path or None on failure.
    """
    try:
        if frame is None:
            return None

        ensure_dir(out_dir)
        ensure_dir(os.path.dirname(csv_file) or ".")

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{light_id}_{ts}.jpg"
        path = os.path.join(out_dir, filename)

        # Write image (BGR expected)
        cv2.imwrite(path, frame)

        # Append to CSV
        write_header = not os.path.exists(csv_file)
        with open(csv_file, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if write_header:
                writer.writerow(["timestamp", "light_id", "zone_id", "image_path", "human_count"])
            writer.writerow([datetime.now().isoformat(), light_id, zone_id, path, human_count])

        return path
    except Exception:
        return None

