import json
import logging
import math
import os
import threading
import time
from collections import defaultdict
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class EnergyUsageRecord:
    """Represents a single energy usage record"""

    def __init__(
        self,
        timestamp: str,
        light_id: str,
        event: str,
        power_watts: float,
        duration_seconds: float = 0,
    ):
        self.timestamp = timestamp  # ISO format
        self.light_id = light_id
        self.event = event  # 'on', 'off', 'usage'
        self.power_watts = power_watts
        self.duration_seconds = duration_seconds
        self.energy_wh = (power_watts * duration_seconds) / 3600  # Watt-hours


class EnergyMonitor:
    """Energy monitoring and analytics system"""

    def __init__(self, config: dict):
        self.config = config
        self.rate_per_kwh = config.get("electricity_rate_per_kwh", 6.5)  # ₹ per kWh
        self.currency = config.get("currency", "₹")

        # Data storage
        self.records: List[EnergyUsageRecord] = []
        self.daily_usage: Dict[str, Dict[str, float]] = defaultdict(
            lambda: defaultdict(float)
        )
        self.monthly_usage: Dict[str, Dict[str, float]] = defaultdict(
            lambda: defaultdict(float)
        )

        # Light state tracking for duration calculation
        self.light_states: Dict[str, Dict] = {}  # light_id -> {state, timestamp, power}

        # Baseline tracking (usage without smart controls)
        self.baseline_hours_per_day = config.get("baseline_hours_per_day", 24)
        self.baseline_total_watts = config.get("baseline_total_watts")
        self.default_light_watts = config.get("light_power_watts", 15)

        # Data persistence
        self.data_file = "data/energy_data.json"
        self.auto_save = True
        self.save_interval = 300  # Save every 5 minutes

        # Background processes
        self.running = True
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop, daemon=True
        )
        self.save_thread = threading.Thread(target=self._save_loop, daemon=True)

        # Load existing data
        self.load_data()

        # Start monitoring
        self.monitor_thread.start()
        self.save_thread.start()

        logger.info("Energy monitoring system initialized")

    def record_light_event(
        self, light_id: str, light_name: str, event: str, power_watts: float
    ):
        """Record a light state change event. Brightness not supported; use full power when on."""
        timestamp = datetime.now().isoformat()
        actual_power = power_watts if event == "on" else 0

        # If light was already on, record the usage duration
        if (
            light_id in self.light_states
            and self.light_states[light_id]["state"] == "on"
        ):
            previous_timestamp = datetime.fromisoformat(
                self.light_states[light_id]["timestamp"]
            )
            duration = (datetime.now() - previous_timestamp).total_seconds()
            previous_power = self.light_states[light_id]["power"]

            # Record the usage for the previous 'on' period
            usage_record = EnergyUsageRecord(
                timestamp=timestamp,
                light_id=light_id,
                event="usage",
                power_watts=previous_power,
                duration_seconds=duration,
            )
            self.records.append(usage_record)

            # Update daily and monthly usage
            self._update_usage_totals(usage_record)

        # Record the state change event
        event_record = EnergyUsageRecord(
            timestamp=timestamp,
            light_id=light_id,
            event=event,
            power_watts=actual_power,
        )
        self.records.append(event_record)

        # Update light state tracking
        self.light_states[light_id] = {
            "state": event,
            "timestamp": timestamp,
            "power": actual_power,
            "name": light_name,
        }

        logger.debug(
            f"Recorded {event} event for light '{light_name}' ({actual_power}W)"
        )

    def _update_usage_totals(self, record: EnergyUsageRecord):
        """Update daily and monthly usage totals"""
        timestamp = datetime.fromisoformat(record.timestamp)
        date_str = timestamp.date().isoformat()
        month_str = timestamp.strftime("%Y-%m")

        # Update daily usage
        self.daily_usage[date_str]["total_wh"] += record.energy_wh
        self.daily_usage[date_str][record.light_id] += record.energy_wh

        # Update monthly usage
        self.monthly_usage[month_str]["total_wh"] += record.energy_wh
        self.monthly_usage[month_str][record.light_id] += record.energy_wh

    def get_current_power_consumption(self) -> float:
        """Get current total power consumption in watts"""
        total_power = 0
        for light_data in self.light_states.values():
            if light_data["state"] == "on":
                total_power += light_data["power"]
        return total_power

    def get_daily_usage(self, target_date: date = None) -> dict:
        """Get energy usage for a specific day"""
        if target_date is None:
            target_date = date.today()

        date_str = target_date.isoformat()
        usage_data = self.daily_usage.get(date_str, {})

        total_wh = usage_data.get("total_wh", 0)
        total_kwh = total_wh / 1000
        total_cost = total_kwh * self.rate_per_kwh

        return {
            "date": date_str,
            "total_wh": total_wh,
            "total_kwh": total_kwh,
            "total_cost": total_cost,
            "currency": self.currency,
            "per_light": {k: v for k, v in usage_data.items() if k != "total_wh"},
        }

    def get_monthly_usage(self, year: int = None, month: int = None) -> dict:
        """Get energy usage for a specific month"""
        if year is None or month is None:
            now = datetime.now()
            year = now.year
            month = now.month

        month_str = f"{year:04d}-{month:02d}"
        usage_data = self.monthly_usage.get(month_str, {})

        total_wh = usage_data.get("total_wh", 0)
        total_kwh = total_wh / 1000
        total_cost = total_kwh * self.rate_per_kwh

        return {
            "month": month_str,
            "total_wh": total_wh,
            "total_kwh": total_kwh,
            "total_cost": total_cost,
            "currency": self.currency,
            "per_light": {k: v for k, v in usage_data.items() if k != "total_wh"},
        }

    def get_weekly_usage(self, start_date: date = None) -> dict:
        """Get energy usage for a week"""
        if start_date is None:
            # Get Monday of current week
            today = date.today()
            start_date = today - timedelta(days=today.weekday())

        weekly_data = {"total_wh": 0, "daily_breakdown": []}

        for i in range(7):
            day = start_date + timedelta(days=i)
            daily_data = self.get_daily_usage(day)
            weekly_data["total_wh"] += daily_data["total_wh"]
            weekly_data["daily_breakdown"].append(daily_data)

        weekly_data["total_kwh"] = weekly_data["total_wh"] / 1000
        weekly_data["total_cost"] = weekly_data["total_kwh"] * self.rate_per_kwh
        weekly_data["currency"] = self.currency

        return weekly_data

    def calculate_energy_savings(self, days: int = 30) -> dict:
        """Calculate energy savings compared to baseline usage"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)

        # Calculate actual usage
        actual_total_wh = 0
        days_with_data = 0

        current_date = start_date
        while current_date <= end_date:
            daily_data = self.get_daily_usage(current_date)
            if daily_data["total_wh"] > 0:  # Only count days with usage data
                actual_total_wh += daily_data["total_wh"]
                days_with_data += 1
            current_date += timedelta(days=1)

        if days_with_data == 0:
            return {
                "period_days": days,
                "actual_kwh": 0,
                "baseline_kwh": 0,
                "savings_kwh": 0,
                "savings_cost": 0,
                "savings_percentage": 0,
                "currency": self.currency,
            }

        # Calculate baseline usage (always-on equivalent)
        if self.baseline_total_watts is not None:
            total_light_power = self.baseline_total_watts
        else:
            total_light_power = sum(
                light_data["power"] for light_data in self.light_states.values()
            )
            if total_light_power == 0:
                # Estimate based on configured default light power
                num_lights = max(1, len(self.light_states))
                total_light_power = num_lights * self.default_light_watts

        baseline_daily_wh = total_light_power * self.baseline_hours_per_day
        baseline_total_wh = baseline_daily_wh * days_with_data

        # Calculate savings
        actual_kwh = actual_total_wh / 1000
        baseline_kwh = baseline_total_wh / 1000
        savings_kwh = max(0, baseline_kwh - actual_kwh)
        savings_cost = savings_kwh * self.rate_per_kwh
        savings_percentage = (
            (savings_kwh / baseline_kwh * 100) if baseline_kwh > 0 else 0
        )

        return {
            "period_days": days_with_data,
            "actual_kwh": actual_kwh,
            "baseline_kwh": baseline_kwh,
            "savings_kwh": savings_kwh,
            "savings_cost": savings_cost,
            "savings_percentage": savings_percentage,
            "currency": self.currency,
        }

    def get_usage_patterns(self, days: int = 7) -> dict:
        """Analyze usage patterns over the specified period"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)

        hourly_usage = defaultdict(float)  # hour -> total_wh
        daily_peaks = []

        # Analyze records for pattern detection
        for record in self.records:
            record_date = datetime.fromisoformat(record.timestamp).date()
            if start_date <= record_date <= end_date and record.event == "usage":
                hour = datetime.fromisoformat(record.timestamp).hour
                hourly_usage[hour] += record.energy_wh

        # Find peak usage hours
        sorted_hours = sorted(hourly_usage.items(), key=lambda x: x[1], reverse=True)
        peak_hours = sorted_hours[:3] if len(sorted_hours) >= 3 else sorted_hours

        # Calculate average daily usage
        total_usage = sum(hourly_usage.values())
        avg_daily_kwh = (total_usage / 1000) / max(days, 1)

        return {
            "period_days": days,
            "hourly_usage": dict(hourly_usage),
            "peak_hours": [
                {"hour": hour, "usage_wh": usage} for hour, usage in peak_hours
            ],
            "avg_daily_kwh": avg_daily_kwh,
            "total_kwh": total_usage / 1000,
        }

    def get_light_efficiency_report(self) -> dict:
        """Generate efficiency report for each light"""
        report = {}

        for light_id, light_data in self.light_states.items():
            light_name = light_data.get("name", f"Light {light_id}")

            # Calculate total usage for this light
            total_wh = 0
            total_on_time = 0

            for record in self.records:
                if record.light_id == light_id and record.event == "usage":
                    total_wh += record.energy_wh
                    total_on_time += record.duration_seconds

            total_kwh = total_wh / 1000
            total_cost = total_kwh * self.rate_per_kwh
            avg_power = (total_wh / (total_on_time / 3600)) if total_on_time > 0 else 0

            report[light_id] = {
                "name": light_name,
                "total_kwh": total_kwh,
                "total_cost": total_cost,
                "total_on_hours": total_on_time / 3600,
                "avg_power_watts": avg_power,
                "efficiency_rating": self._calculate_efficiency_rating(
                    avg_power, total_on_time
                ),
            }

        return report

    def _calculate_efficiency_rating(
        self, avg_power: float, on_time_seconds: float
    ) -> str:
        """Calculate efficiency rating based on usage patterns"""
        if on_time_seconds < 3600:  # Less than 1 hour
            return "Insufficient Data"

        # Simple efficiency rating based on average power and usage
        if avg_power < 10:
            return "Excellent"
        elif avg_power < 20:
            return "Good"
        elif avg_power < 30:
            return "Fair"
        else:
            return "Poor"

    def _monitoring_loop(self):
        """Background monitoring loop"""
        while self.running:
            # Update usage for currently on lights
            current_time = datetime.now()

            for light_id, light_data in self.light_states.items():
                if light_data["state"] == "on":
                    # Calculate usage since last update
                    last_update = datetime.fromisoformat(light_data["timestamp"])
                    duration = (current_time - last_update).total_seconds()

                    if duration > 60:  # Update every minute
                        # Record usage
                        usage_record = EnergyUsageRecord(
                            timestamp=current_time.isoformat(),
                            light_id=light_id,
                            event="usage",
                            power_watts=light_data["power"],
                            duration_seconds=duration,
                        )
                        self.records.append(usage_record)
                        self._update_usage_totals(usage_record)

                        # Update timestamp
                        light_data["timestamp"] = current_time.isoformat()

            time.sleep(60)  # Monitor every minute

    def _save_loop(self):
        """Background save loop"""
        while self.running:
            time.sleep(self.save_interval)
            if self.auto_save:
                self.save_data()

    def save_data(self, filename: str = None):
        """Save energy data to file"""
        filename = filename or self.data_file

        try:
            os.makedirs(os.path.dirname(filename), exist_ok=True)

            data = {
                "records": [
                    {
                        "timestamp": record.timestamp,
                        "light_id": record.light_id,
                        "event": record.event,
                        "power_watts": record.power_watts,
                        "duration_seconds": record.duration_seconds,
                        "energy_wh": record.energy_wh,
                    }
                    for record in self.records
                ],
                "daily_usage": dict(self.daily_usage),
                "monthly_usage": dict(self.monthly_usage),
                "light_states": self.light_states,
                "config": self.config,
                "saved_at": datetime.now().isoformat(),
            }

            with open(filename, "w") as f:
                json.dump(data, f, indent=2)

            logger.debug(f"Saved energy data with {len(self.records)} records")

        except Exception as e:
            logger.error(f"Failed to save energy data: {e}")

    def load_data(self, filename: str = None):
        """Load energy data from file"""
        filename = filename or self.data_file

        if not os.path.exists(filename):
            logger.info(f"No existing energy data file found at {filename}")
            return

        try:
            with open(filename, "r") as f:
                data = json.load(f)

            # Load records
            self.records = []
            for record_data in data.get("records", []):
                record = EnergyUsageRecord(
                    timestamp=record_data["timestamp"],
                    light_id=record_data["light_id"],
                    event=record_data["event"],
                    power_watts=record_data["power_watts"],
                    duration_seconds=record_data["duration_seconds"],
                )
                self.records.append(record)

            # Load usage totals - ensure nested defaultdicts
            loaded_daily = data.get("daily_usage", {})
            self.daily_usage = defaultdict(lambda: defaultdict(float))
            for date_str, day_data in loaded_daily.items():
                self.daily_usage[date_str] = defaultdict(float, day_data)

            loaded_monthly = data.get("monthly_usage", {})
            self.monthly_usage = defaultdict(lambda: defaultdict(float))
            for month_str, month_data in loaded_monthly.items():
                self.monthly_usage[month_str] = defaultdict(float, month_data)

            # Load light states
            self.light_states = data.get("light_states", {})

            logger.info(f"Loaded energy data with {len(self.records)} records")

        except Exception as e:
            logger.error(f"Failed to load energy data: {e}")

    def cleanup(self):
        """Clean up resources"""
        self.running = False

        # Wait for threads to finish
        if hasattr(self, "monitor_thread"):
            self.monitor_thread.join(timeout=2)
        if hasattr(self, "save_thread"):
            self.save_thread.join(timeout=2)

        # Final save
        self.save_data()
        logger.info("Energy monitor cleanup completed")
