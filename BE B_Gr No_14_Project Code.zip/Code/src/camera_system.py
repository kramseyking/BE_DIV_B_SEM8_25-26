import json
import logging
import platform
import threading
import time
from datetime import datetime
from typing import List, Optional, Tuple

import cv2
import numpy as np
import glob
import os
from ultralytics import YOLO

try:
    # Prefer Picamera2 (libcamera) on modern Raspberry Pi OS
    from picamera2 import Picamera2

    PI_CAMERA2_AVAILABLE = True
except Exception:
    PI_CAMERA2_AVAILABLE = False

logger = logging.getLogger(__name__)


class CameraManager:
    """Cross-platform camera manager supporting both USB cameras and Pi Camera (Picamera2)"""

    def __init__(self, config: dict):
        self.config = config
        # Consider both 32-bit and 64-bit ARM architectures (arm, aarch64)
        mach = platform.machine().lower()
        self.is_raspberry_pi = mach.startswith("arm") or mach.startswith("aarch64")

        # Use Picamera2 on Raspberry Pi when requested in config (pi_camera2: true)
        self.use_pi_camera = (
            self.is_raspberry_pi
            and config.get("pi_camera2", True)
            and PI_CAMERA2_AVAILABLE
        )

        self.cap = None
        self.pi_camera = None
        self.pi_raw_capture = None
        self.frame = None
        self.running = False
        self.lock = threading.Lock()

        # Camera settings
        self.width = config.get("width", 640)
        self.height = config.get("height", 480)
        self.fps = config.get("fps", 10)

    def start(self) -> bool:
        """Initialize and start the camera"""
        try:
            # On Raspberry Pi, allow either Picamera2 or USB camera based on config
            if self.is_raspberry_pi:
                if self.use_pi_camera:
                    if not PI_CAMERA2_AVAILABLE:
                        logger.error(
                            "Picamera2 not available. Ensure libcamera is installed: python3 -m pip install picamera2"
                        )
                        return False
                    return self._start_pi_camera()

                logger.info("Pi detected but Picamera2 disabled; using USB camera")
                return self._start_usb_camera()

            # On other platforms (Windows, Linux desktop), use USB camera
            return self._start_usb_camera()
        except Exception as e:
            logger.error(f"Failed to start camera: {e}")
            return False

    def _start_pi_camera(self) -> bool:
        """Start Raspberry Pi camera"""
        try:
            # Use Picamera2 (libcamera) - assumes camera is the CSI camera (cam0)
            # Force use of cam0 (CSI 15-pin) by selecting camera_num=0
            try:
                self.picam2 = Picamera2(camera_num=0)
            except TypeError:
                # Older Picamera2 builds may not accept camera_num; fall back to default
                self.picam2 = Picamera2()
            config = self.picam2.create_video_configuration(
                main={"size": (self.width, self.height)}
            )
            self.picam2.configure(config)
            self.picam2.start()

            # small warm-up
            time.sleep(0.5)

            self.running = True
            self.capture_thread = threading.Thread(target=self._pi_capture_loop)
            self.capture_thread.daemon = True
            self.capture_thread.start()

            logger.info("Picamera2 started successfully (cam0)")
            return True
        except Exception as e:
            logger.error(f"Failed to start Pi camera: {e}")
            return False

    def _start_usb_camera(self) -> bool:
        """Start USB camera"""
        try:
            camera_source = self.config.get("source", 0)

            # Try sensible backends and device paths on Linux (Raspberry Pi)
            tried = []

            def try_open(src, api_preference=None):
                tried.append((src, api_preference))
                if api_preference is not None:
                    cap = cv2.VideoCapture(src, api_preference)
                else:
                    cap = cv2.VideoCapture(src)
                if cap is not None and cap.isOpened():
                    return cap
                # release if partially created
                try:
                    if cap is not None:
                        cap.release()
                except Exception:
                    pass
                return None

            cap = None

            # If camera_source is an integer index, try it first with V4L2 (Linux)
            if isinstance(camera_source, int):
                # Prefer V4L2 backend on Linux to ensure proper device usage
                if os.name == "posix":
                    cap = try_open(camera_source, cv2.CAP_V4L2)
                if cap is None:
                    cap = try_open(camera_source, None)

            # If camera_source looks like a path (/dev/video0), try that explicitly
            if cap is None and isinstance(camera_source, str):
                cap = try_open(camera_source, cv2.CAP_V4L2)
                if cap is None:
                    cap = try_open(camera_source, None)

            # As a robust fallback on Linux, probe /dev/video* devices
            if cap is None and os.name == "posix":
                for dev in sorted(glob.glob("/dev/video*")):
                    cap = try_open(dev, cv2.CAP_V4L2)
                    if cap:
                        logger.debug(f"Opened camera via device path {dev}")
                        break
                    cap = try_open(dev, None)
                    if cap:
                        logger.debug(f"Opened camera via device path {dev} (no explicit backend)")
                        break

            # Final fallback: try indices 0..3 without explicit backend
            if cap is None:
                for idx in range(0, 4):
                    cap = try_open(idx, None)
                    if cap:
                        logger.debug(f"Opened camera via index {idx} as final fallback")
                        break

            self.cap = cap

            if self.cap is None or not self.cap.isOpened():
                logger.error(f"Cannot open camera. Tried: {tried}")
                return False

            # Set camera properties
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            self.cap.set(cv2.CAP_PROP_FPS, self.fps)

            self.running = True
            self.capture_thread = threading.Thread(target=self._usb_capture_loop)
            self.capture_thread.daemon = True
            self.capture_thread.start()

            logger.info("USB Camera started successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to start USB camera: {e}")
            return False

    def _pi_capture_loop(self):
        """Capture loop for Pi camera"""
        try:
            while self.running:
                # capture_array returns a numpy array (RGB)
                frame = self.picam2.capture_array()
                # convert to BGR which OpenCV expects
                if frame is not None:
                    with self.lock:
                        self.frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                time.sleep(1 / max(self.fps, 1))
        except Exception as e:
            logger.error(f"Pi camera capture error: {e}")

    def _usb_capture_loop(self):
        """Capture loop for USB camera"""
        try:
            while self.running:
                ret, frame = self.cap.read()
                if ret:
                    with self.lock:
                        self.frame = frame.copy()
                else:
                    logger.warning("Failed to read frame from USB camera")
                    time.sleep(0.1)
        except Exception as e:
            logger.error(f"USB camera capture error: {e}")

    def get_frame(self) -> Optional[np.ndarray]:
        """Get the latest frame"""
        with self.lock:
            return self.frame.copy() if self.frame is not None else None

    def stop(self):
        """Stop the camera"""
        self.running = False

        if hasattr(self, "capture_thread"):
            self.capture_thread.join(timeout=2)

        if self.cap:
            self.cap.release()

        if hasattr(self, "picam2") and self.picam2 is not None:
            try:
                self.picam2.close()
            except Exception:
                pass

        logger.info("Camera stopped")


class HumanDetector:
    """Human detection using YOLO"""

    def __init__(self, config: dict):
        self.config = config
        self.model_path = config.get("model", "yolov8n.pt")
        self.confidence = config.get("confidence", 0.5)
        self.device = config.get("device", "cpu")

        # Load YOLO model
        try:
            self.model = YOLO(self.model_path)
            logger.info(f"YOLO model loaded: {self.model_path}")
        except Exception as e:
            logger.error(f"Failed to load YOLO model: {e}")
            raise

        # Track detection history for stability
        self.track_history = config.get("track_history", 30)
        self.detection_history = []

    def detect_humans(
        self, frame: np.ndarray
    ) -> List[Tuple[int, int, int, int, float]]:
        """
        Detect humans in the frame
        Returns: List of (x1, y1, x2, y2, confidence) tuples
        """
        if frame is None:
            return []

        try:
            # Run YOLO detection
            results = self.model(frame, device=self.device, verbose=False)

            detections = []
            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for box in boxes:
                        # Class 0 is 'person' in COCO dataset
                        if int(box.cls) == 0 and float(box.conf) >= self.confidence:
                            x1, y1, x2, y2 = box.xyxy[0].tolist()
                            conf = float(box.conf)
                            detections.append(
                                (int(x1), int(y1), int(x2), int(y2), conf)
                            )

            # Add to history for stability
            self.detection_history.append(len(detections))
            if len(self.detection_history) > self.track_history:
                self.detection_history.pop(0)

            return detections

        except Exception as e:
            logger.error(f"Detection error: {e}")
            return []

    def get_stable_human_count(self) -> int:
        """Get a stable human count based on recent history"""
        if not self.detection_history:
            return 0

        # Use median of recent detections for stability
        return int(np.median(self.detection_history))

    def draw_detections(
        self, frame: np.ndarray, detections: List[Tuple[int, int, int, int, float]]
    ) -> np.ndarray:
        """Draw detection boxes on frame"""
        frame_with_detections = frame.copy()

        for x1, y1, x2, y2, conf in detections:
            # Draw bounding box
            cv2.rectangle(frame_with_detections, (x1, y1), (x2, y2), (0, 255, 0), 2)

            # Draw confidence
            label = f"Person: {conf:.2f}"
            cv2.putText(
                frame_with_detections,
                label,
                (x1, y1 - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 255, 0),
                1,
            )

        return frame_with_detections


class CameraSystem:
    """Main camera system combining camera and detection"""

    def __init__(self, config: dict):
        self.camera_config = config.get("camera", {})
        self.detection_config = config.get("detection", {})

        self.camera = CameraManager(self.camera_config)
        self.detector = HumanDetector(self.detection_config)

        self.running = False
        self.current_detections = []
        self.current_frame = None
        self.detection_lock = threading.Lock()

    def start(self) -> bool:
        """Start the camera system"""
        if not self.camera.start():
            logger.error("Camera failed to start - aborting camera system")
            return False

        self.running = True
        self.detection_thread = threading.Thread(target=self._detection_loop)
        self.detection_thread.daemon = True
        self.detection_thread.start()

        logger.info("Camera system started")
        return True

    def _detection_loop(self):
        """Main detection loop"""
        while self.running:
            frame = self.camera.get_frame()

            if frame is not None:
                detections = self.detector.detect_humans(frame)

                with self.detection_lock:
                    self.current_detections = detections
                    self.current_frame = frame

            time.sleep(0.1)  # Limit detection rate for performance

    def get_current_status(self) -> dict:
        """Get current detection status"""
        with self.detection_lock:
            return {
                "human_count": len(self.current_detections),
                "stable_count": self.detector.get_stable_human_count(),
                "detections": self.current_detections.copy(),
                "has_frame": self.current_frame is not None,
            }

    def get_frame_with_detections(self) -> Optional[np.ndarray]:
        """Get current frame with detection overlays"""
        with self.detection_lock:
            if self.current_frame is not None:
                return self.detector.draw_detections(
                    self.current_frame, self.current_detections
                )
        return None

    def get_clean_frame(self) -> Optional[np.ndarray]:
        """Get current frame without overlays"""
        return self.camera.get_frame()

    def capture_snapshot(self) -> Optional[np.ndarray]:
        """Capture a snapshot for zone definition"""
        return self.get_clean_frame()

    def stop(self):
        """Stop the camera system"""
        self.running = False

        if hasattr(self, "detection_thread"):
            self.detection_thread.join(timeout=2)

        self.camera.stop()
        logger.info("Camera system stopped")


# Utility functions
def encode_frame_to_jpeg(frame: np.ndarray, quality: int = 70) -> bytes:
    """Encode frame to JPEG bytes for web streaming"""
    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
    _, buffer = cv2.imencode(".jpg", frame, encode_param)
    return buffer.tobytes()


def resize_frame_for_web(frame: np.ndarray, max_width: int = 800) -> np.ndarray:
    """Resize frame for web display while maintaining aspect ratio"""
    height, width = frame.shape[:2]
    if width > max_width:
        ratio = max_width / width
        new_width = max_width
        new_height = int(height * ratio)
        frame = cv2.resize(frame, (new_width, new_height))
    return frame
