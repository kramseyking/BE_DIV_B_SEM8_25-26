#!/usr/bin/env python3
"""
GPIO Pin Test Script
Tests GPIO pins 17, 22, and 27
"""

import time

try:
    import RPi.GPIO as GPIO
    USE_RPIGPIO = True
except ImportError:
    USE_RPIGPIO = False
    try:
        from gpiozero import LED
        USE_GPIOZERO = True
    except ImportError:
        USE_GPIOZERO = False

TEST_PINS = [17, 22, 27]


def test_with_rpigpio():
    """Test using RPi.GPIO library"""
    print("Using RPi.GPIO library")
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    
    # Setup pins as outputs
    for pin in TEST_PINS:
        GPIO.setup(pin, GPIO.OUT)
        print(f"  Pin {pin} configured as output")
    
    print("\nTesting pins (ON for 2 seconds, then OFF)...")
    for pin in TEST_PINS:
        print(f"\n  Pin {pin}: ON")
        GPIO.output(pin, GPIO.HIGH)
        time.sleep(2)
        print(f"  Pin {pin}: OFF")
        GPIO.output(pin, GPIO.LOW)
        time.sleep(0.5)
    
    print("\nAll pins test cycle...")
    for cycle in range(3):
        print(f"  Cycle {cycle + 1}: All ON")
        for pin in TEST_PINS:
            GPIO.output(pin, GPIO.HIGH)
        time.sleep(1)
        
        print(f"  Cycle {cycle + 1}: All OFF")
        for pin in TEST_PINS:
            GPIO.output(pin, GPIO.LOW)
        time.sleep(1)
    
    # Cleanup
    GPIO.cleanup()
    print("\nGPIO cleanup complete")


def test_with_gpiozero():
    """Test using gpiozero library"""
    print("Using gpiozero library")
    
    leds = {pin: LED(pin) for pin in TEST_PINS}
    
    for pin in TEST_PINS:
        print(f"  Pin {pin} configured as output")
    
    print("\nTesting pins (ON for 2 seconds, then OFF)...")
    for pin in TEST_PINS:
        print(f"\n  Pin {pin}: ON")
        leds[pin].on()
        time.sleep(2)
        print(f"  Pin {pin}: OFF")
        leds[pin].off()
        time.sleep(0.5)
    
    print("\nAll pins test cycle...")
    for cycle in range(3):
        print(f"  Cycle {cycle + 1}: All ON")
        for led in leds.values():
            led.on()
        time.sleep(1)
        
        print(f"  Cycle {cycle + 1}: All OFF")
        for led in leds.values():
            led.off()
        time.sleep(1)
    
    # Cleanup
    for led in leds.values():
        led.close()
    print("\nGPIO cleanup complete")


def main():
    print("=" * 50)
    print("GPIO Pin Test - Pins 17, 22, 27")
    print("=" * 50)
    print()
    
    if not USE_RPIGPIO and not USE_GPIOZERO:
        print("ERROR: No GPIO library found!")
        print("Install one of:")
        print("  sudo apt install python3-rpi.gpio")
        print("  sudo apt install python3-gpiozero")
        return
    
    try:
        if USE_RPIGPIO:
            test_with_rpigpio()
        elif USE_GPIOZERO:
            test_with_gpiozero()
        
        print("\n" + "=" * 50)
        print("Test completed successfully!")
        print("=" * 50)
        
    except KeyboardInterrupt:
        print("\n\nTest interrupted by user")
        if USE_RPIGPIO:
            GPIO.cleanup()
    except Exception as e:
        print(f"\nERROR: {e}")
        if USE_RPIGPIO:
            GPIO.cleanup()


if __name__ == "__main__":
    main()
