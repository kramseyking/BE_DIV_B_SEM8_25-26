#!/usr/bin/env python3
"""
Smart Lighting Control System
Main entry point for the application
"""

import argparse
import logging
import os
import sys
import json
import tempfile
import platform

from app import create_app


def setup_logging(debug=False):
    """Setup logging configuration"""
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler("smart_lighting.log"),
        ],
    )


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Smart Lighting Control System")
    parser.add_argument(
        "--config", default="config.json", help="Configuration file path"
    )
    parser.add_argument("--host", default=None, help="Host to bind to")
    parser.add_argument("--port", type=int, default=None, help="Port to bind to")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")

    args = parser.parse_args()

    # Setup logging
    setup_logging(args.debug)
    logger = logging.getLogger(__name__)

    try:
        # Create and run the application
        logger.info("Starting Smart Lighting Control System")
        # If running on a Raspberry Pi with a ribbon (CSI) camera, prefer Picamera2.
        # The repository config.json may have "pi_camera2": false for desktop testing.
        # To avoid overwriting the user's config file, create a temporary override
        # config enabling pi_camera2 when we detect an ARM platform and the
        # config explicitly disables pi_camera2.
        config_path = args.config
        try:
            if platform.machine().startswith("arm") or platform.machine().startswith("aarch64"):
                if os.path.exists(config_path):
                    with open(config_path, "r") as cf:
                        cfg = json.load(cf)

                    cam_cfg = cfg.get("camera", {})
                    if not cam_cfg.get("pi_camera2", False):
                        # create a temporary config file that forces pi_camera2 = true
                        cfg_copy = cfg.copy()
                        cfg_copy.setdefault("camera", {})
                        cfg_copy["camera"]["pi_camera2"] = True
                        tf = tempfile.NamedTemporaryFile(delete=False, suffix=".json")
                        json.dump(cfg_copy, open(tf.name, "w"), indent=2)
                        logger.info(f"Detected Raspberry Pi platform; using temporary config {tf.name} with pi_camera2 enabled")
                        config_path = tf.name
        except Exception as e:
            logger.warning(f"Could not adjust config for Pi camera auto-detect: {e}")

        app = create_app(config_path)
        app.run(host=args.host, port=args.port, debug=args.debug)

    except KeyboardInterrupt:
        logger.info("Shutting down gracefully...")
    except Exception as e:
        logger.error(f"Application error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
