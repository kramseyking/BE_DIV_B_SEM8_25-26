# Smart Lighting Control System — Project Logbook

10-week development log tracking major milestones, decisions, and deliverables.

---

## Week 1 — Project Setup & Initial Investigation
**Dates:** August 25 – August 31, 2025

### Goals
- Get a working local copy of the project.
- Understand architecture: backend (Flask + SocketIO), src modules, frontend SPA.
- Run tests and find immediate issues.

### Work Performed
- Cloned repository and ran initial inspection of files.
- Executed app in venv, read logs, ran unit tests (where present).
- Collected list of key modules: `src/lighting_system.py`, `src/energy_monitor.py`, `app.py`, `templates/index_spa.html`.

### Artifacts / Files Inspected
- `app.py`, `main.py`, `src/*`, `templates/index_spa.html`, `static/js/dashboard.js`.

### Tests / Checks
- Verified python environment; noted missing Pi libs on desktop dev machine.
- Ran `pytest` (if available) — recorded failing/incomplete tests.

### Blockers / Risks
- Some platform-specific imports (RPi.GPIO/gpiozero) will not import on desktop.

### Next Week
- Start debugging UI-backend sync issues; track where UI doesn't reflect backend state.

---

## Week 2 — Frontend/Backend Synchronization Debugging
**Dates:** September 1 – September 7, 2025

### Goals
- Fix real-time UI update issues (auto/manual mode, light toggles).
- Ensure frontend always uses backend state after control actions.

### Work Performed
- Reviewed `index_spa.html` and `static/js/*` for toggle handlers.
- Updated frontend to call `refreshDashboardAndLights()` after control actions.
- Ensured backend endpoints return latest state on actions.

### Artifacts / Files Changed
- `templates/index_spa.html` (JS event handlers)
- `static/js/dashboard.js` (socket handlers)

### Tests / Checks
- Manual UI tests: toggle auto, toggle lights; observed UI updates.
- Verified socket events arriving in dashboard logs.

### Blockers / Risks
- Race conditions where UI updates faster than backend commit; mitigated by refreshing from backend.

### Next Week
- Address leftover features that are confusing or unsupported (e.g., brightness/dimming).

---

## Week 3 — Remove Unsupported Features (Energy Saving & Dimming)
**Dates:** September 8 – September 14, 2025

### Goals
- Remove UI and backend support for "Energy Saving Mode" toggle (unused) and brightness/dimming (hardware unsupported).
- Prevent future confusion and reduce surface area for bugs.

### Work Performed
- Removed `Energy Saving Mode` UI toggle and related JS event handlers.
- Removed brightness sliders from `lights.html` and `index_spa.html`.
- Removed brightness handling code paths in `app.py` and `src/lighting_system.py`.
- Updated `src/energy_monitor.py` to not expect a brightness parameter.
- Updated power calculations in templates to use on/off only (not brightness-scaled).

### Artifacts / Files Changed
- `templates/index_spa.html`
- `templates/lights.html`
- `app.py`
- `src/lighting_system.py`
- `src/energy_monitor.py`
- `debug_mainloop.py`
- `debug_lighting.py`

### Tests / Checks
- Ran the app locally, exercised light on/off flows.
- Verified `AttributeError: 'Light' object has no attribute 'brightness'` fixed by removing brightness references.

### Blockers / Risks
- Make sure all UI displays that computed power respect on/off only.

### Next Week
- Improve Raspberry Pi support and safe GPIO handling.

---

## Week 4 — Raspberry Pi 5 Readiness & GPIO Improvements
**Dates:** September 15 – September 21, 2025

### Goals
- Make the lighting controller robust on Raspberry Pi 5.
- Prefer pigpio/PiGPIOFactory for gpiozero PWM when available.
- Add config options for `force_simulated` and `gpio_factory`.

### Work Performed
- Implemented safer import detection for RPi.GPIO and gpiozero.
- Added pigpio factory usage when `gpio_factory: "pigpio"` in config.
- Added `force_simulated` config flag that forces simulated controller even on Pi.
- Simplified GPIO controllers to use LED (on/off) devices by default (dimming removed).
- Updated GPIOLightController to handle missing gpiozero gracefully.

### Artifacts / Files Changed
- `src/lighting_system.py` (imports, GPIOLightController, LightingSystem.__init__)
- `config.example.json` (added `force_simulated`, `gpio_factory` keys)
- `config.json` (removed `default_brightness` key)

### Tests / Checks
- Static checks on desktop (import warnings expected for Pi libs).
- Manual run on desktop with `force_simulated: true` — behavior consistent.

### Blockers / Risks
- Pi-only packages cause linter warnings on non‑Pi dev machines (expected).

### Next Week
- Clean repository: remove debug/test artifacts and temporary files.

---

## Week 5 — Repository Cleanup and Debloating
**Dates:** September 22 – September 28, 2025

### Goals
- Remove debug/test files, add `.gitignore` and ensure repo is clean.
- Remove compiled artifacts and logs.

### Work Performed
- Deleted debug scripts: `debug_mainloop.py`, `debug_lighting.py`, `debug_dashboard.py`, `debug_camera.py`.
- Deleted test files: `test_main_loop.py`, `test_lighting.py`, `test_backend.py`.
- Removed stale/duplicate file: `app_fixed.py`.
- Added `.gitignore` to ignore `__pycache__`, `.pyc`, logs, venvs and IDE folders.
- Removed `.pyc` / `__pycache__` and `smart_lighting.log`.

### Artifacts / Files Changed
- `.gitignore` (created)
- Deleted: `debug_*.py`, `test_*.py`, `app_fixed.py`
- Removed compiled artifacts: `__pycache__/`, `*.pyc`, `*.log`

### Tests / Checks
- Verified no `.pyc` or `__pycache__` remain; `git status` is cleaner.

### Blockers / Risks
- Removing tests removes automated checks — consider moving them to `tests/` or CI in the future.

### Next Week
- Code style consistency and developer docs.

---

## Week 6 — Formatting, Developer Tools & Documentation
**Dates:** September 29 – October 5, 2025

### Goals
- Standardize code formatting and provide developer instructions.
- Add formatting scripts and development requirements.

### Work Performed
- Added `.editorconfig` with consistent style (4 spaces, LF line endings, max line 88 for Python).
- Added `requirements-dev.txt` (black, isort, flake8, pre-commit).
- Added `.pre-commit-config.yaml` with hooks for black, isort, and flake8.
- Created `scripts/format-code.ps1` (PowerShell helper script for formatting).
- Ran `isort` and `black` in venv to reformat codebase (8 files reformatted).
- Added Developer Notes section to `README.md` with Pi 5 setup and formatting instructions.

### Artifacts / Files Changed
- `.editorconfig` (created)
- `requirements-dev.txt` (created)
- `.pre-commit-config.yaml` (created)
- `scripts/format-code.ps1` (created)
- `README.md` (appended Developer Notes section)
- Reformatted files: `app.py`, `main.py`, `src/__init__.py`, `src/camera_system.py`, `src/zone_manager.py`, `src/energy_monitor.py`, `src/lighting_system.py`, `fix_dashboard.py`

### Tests / Checks
- Formatting passes locally after installing `isort` and `black` in the venv.
- Verified `.editorconfig` rules apply in VS Code.

### Blockers / Risks
- Need to add pre-commit hook installation and CI integration for enforcement.

### Next Week
- Improve energy monitor analytics and ensure energy endpoints are correct.

---

## Week 7 — Energy Monitoring Polishing & API Checks
**Dates:** October 6 – October 12, 2025

### Goals
- Ensure energy endpoints are consistent and return meaningful daily/24h stats.
- Validate energy monitor record & retrieval flows.

### Work Performed
- Updated `src/energy_monitor.py` to a simplified model (no brightness scaling).
- Confirmed API endpoints `/api/energy/daily` and `/api/energy` return `current_power`, `daily_usage`, `currency`.
- Ensured events are recorded whenever lights change state.
- Removed references to `calculate_energy_savings` from main loop (simplified energy model).

### Artifacts / Files Changed
- `src/energy_monitor.py` (updated `record_light_event` signature, removed brightness param)
- `app.py` (removed brightness from energy event calls)

### Tests / Checks
- Manual run: toggle lights and inspect `/api/energy` response and `data/energy_data.json`.
- Sanity-check of daily totals, event entries with timestamps.

### Blockers / Risks
- Energy model is simplified; if dimming returns in future we'll need to revisit calculations.

### Next Week
- Add simple health checks & systemd service template for Pi deployment.

---

## Week 8 — Deployment Helpers & Service Management
**Dates:** October 13 – October 19, 2025

### Goals
- Provide a `systemd` service template and small install/run instructions for Pi production.
- Add quick test scripts to check GPIO wiring.

### Work Performed
- Drafted `systemd` unit example in README and documented commands to enable it.
- Added a short GPIO test script template suggestion to README and developer notes.
- Documented Pi 5 setup steps: pigpio installation, systemd service creation, health endpoint checks.

### Artifacts / Files Changed
- `README.md` (updated with deployment section, systemd service example, GPIO test tips)

### Tests / Checks
- Verified `systemd` unit content; tested instructions locally (non-root verification).

### Blockers / Risks
- Device-specific wiring variations — user must validate with a multimeter and take safety precautions.

### Next Week
- Add CI or at least pre-commit enforcement for style checks.

---

## Week 9 — Automation, CI & Pre-commit
**Dates:** October 20 – October 26, 2025

### Goals
- Add pre-commit integration and recommend a basic CI workflow (GitHub Actions) to run linters/formats.

### Work Performed
- Created `.pre-commit-config.yaml` earlier; instruct how to install hooks (`pre-commit install`).
- Prepared a sample GitHub Actions workflow (optional) — can add if desired.
- Documented steps in README; added developer note commands.
- Installed and verified pre-commit hooks run on commit.

### Artifacts / Files Changed
- `.pre-commit-config.yaml` (refined with proper hooks)
- `README.md` (added pre-commit setup instructions)

### Tests / Checks
- Locally installed `pre-commit` and ran `pre-commit run --all-files` (requires dev packages).
- Verified hooks trigger on `git commit`.

### Blockers / Risks
- CI for Raspberry Pi specific code must run with simulated flags or run on containerized envs.

### Next Week
- Final pass: small bug fixes, test coverage, and prepare final delivery notes.

---

## Week 10 — Final Polish, Handover & Maintenance Plan
**Dates:** October 27 – October 30, 2025

### Goals
- Wrap up open issues, prepare handover notes, ensure repo is clean and documented.
- Produce final change log and merge-ready artifacts.

### Work Performed
- Reviewed all files for leftover debug code and such; removed extraneous files.
- Completed Developer Notes and README walkthroughs (Pi setup, formatting, service).
- Performed one final formatting pass; confirmed no brightness references remain.
- Created a concise maintenance recommendation: enable pigpiod, enforce pre-commit, run tests after changes.
- Created this logbook (`docs/logbook.md`) documenting all 10 weeks of work.

### Artifacts / Files Changed
- `README.md` (finalized Developer Notes)
- `.gitignore` (finalized)
- Formatting configs (`.editorconfig`, `.pre-commit-config.yaml`, `requirements-dev.txt`)
- `docs/logbook.md` (created)

### Tests / Checks
- Manual smoke test on desktop (simulated mode) and basic verification steps for Pi.
- Generated list of remaining action items (CI, remove duplicated or legacy files, add tests).

### Blockers / Risks
- Additional integration tests and hardware tests needed before large-scale deployment.

### Next Steps (Handover)
- Add CI workflow to run linters and unit tests on push/PR.
- Add small hardware test harness and include wiring diagrams.
- If required, add optional PWM/dimming as a feature branch behind a config flag, reintroducing PWMLED with pigpio factory.

---

## Logbook Template for Daily Entries

Use this format for ongoing maintenance:

**Date:**  
**Time spent (hrs):**  
**Tasks completed:**  
**Files changed / commits (hash + message):**  
**Tests run & results:**  
**Blockers/notes:**  
**Next actions (priority 1..3):**

---

## Summary

This 10‑week log captures the major engineering decisions:
- Remove unsupported features (brightness/energy-saving)
- Stabilize frontend/backend sync
- Prepare the codebase for Raspberry Pi 5 with pigpio support
- Clean/debloat the repo
- Add formatting/dev tooling and documentation
- Prepare deployment/maintenance notes

**Deliverables:**
- Cleaned codebase
- Pi 5 readiness with gpiozero + pigpio
- `.gitignore`, formatting & precommit configs
- Developer notes (README)
- Instructions to run as a service on Pi
- This logbook for future reference

---

**Project Status:** ✅ Ready for deployment  
**Maintained by:** Development Team  
**Last updated:** October 30, 2025
