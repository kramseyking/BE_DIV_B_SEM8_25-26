# Smart Lighting System - Gantt Chart (January to March 2026)

Time window: January 2026 to March 2026

```mermaid
gantt
    title Smart Lighting Control System - January to March 2026
    dateFormat  YYYY-MM-DD
    axisFormat  %d %b
    excludes    weekends

    section Planning and Baseline
    Scope freeze and milestone lock            :done, p1, 2026-01-06, 4d
    Baseline metrics and acceptance criteria   :done, p2, after p1, 3d

    section Camera and Detection
    Camera fallback reliability hardening      :done, c1, 2026-01-13, 10d
    YOLO detection threshold tuning            :c2, after c1, 8d
    Detection stability and false-positive QA  :c3, after c2, 6d

    section Zone and Lighting Logic
    Zone mapper UX cleanup                     :z1, 2026-01-20, 7d
    Auto/manual control edge-case fixes        :z2, after z1, 8d
    GPIO behavior validation (Pi + simulated)  :z3, after z2, 7d

    section Dashboard and APIs
    SPA dashboard state-sync improvements      :d1, 2026-02-03, 8d
    Energy endpoint consistency pass            :d2, after d1, 6d
    Upload flow polish and status messaging    :d3, after d2, 5d

    section Data and Reporting
    Energy model sanity checks                 :e1, 2026-02-17, 6d
    Daily and monthly report script updates    :e2, after e1, 7d
    Documentation refresh (guides and README)  :e3, after e2, 5d

    section Quality and Deployment
    Automated test expansion                   :q1, 2026-03-03, 9d
    Raspberry Pi deployment dry run            :q2, after q1, 6d
    Performance and soak testing               :q3, after q2, 6d

    section Release
    Final bug bash and fix sprint              :done, r1, 2026-03-20, 6d
    Release prep and handoff                   :milestone, r2, 2026-03-31, 1d
```

Notes:
- Timeline reflects the previous three full months before April 2026.
- All tasks are shown as completed milestones for retrospective reporting.
