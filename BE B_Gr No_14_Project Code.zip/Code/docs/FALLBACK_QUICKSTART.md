# 🚨 Camera Fallback Mode - Quick Reference

## What is it?
A backup system that lets you upload still images for detection when the camera is broken.

## When to use?
- ✅ Camera hardware failure
- ✅ Testing without camera
- ✅ Remote image uploads
- ✅ Manual lighting control

## Quick Setup (3 steps)

### Step 1: Enable in Config
Edit `config.json`:
```json
{
  "fallback_mode": true
}
```

### Step 2: Start System
```bash
python main.py
```

### Step 3: Upload Images
Open web dashboard → Look for yellow "Fallback Mode" warning → Click "Upload & Detect"

## 📱 Web Interface

**What you'll see:**
- Yellow warning: "Camera Fallback Mode: Upload images for detection"
- File upload button
- "Upload & Detect" button
- Last upload time
- Detection count

## 🔌 API Usage

**Upload via command line:**
```bash
curl -X POST -F "image=@photo.jpg" http://localhost:5000/api/camera/upload
```

**Upload via Python:**
```python
import requests

with open('photo.jpg', 'rb') as f:
    response = requests.post(
        'http://localhost:5000/api/camera/upload',
        files={'image': f}
    )
    print(response.json())
```

## ⚙️ How Detection Works

1. You upload an image
2. YOLO AI detects people
3. System counts people in zones
4. Lights turn on/off automatically
5. Dashboard updates

## 💡 Tips

- Upload clear, well-lit images
- Use same camera angle as original setup
- Update every 5-10 minutes for best results
- Supported formats: JPG, PNG, BMP
- Image size: 640x480 to 1920x1080 recommended

## 🔄 Switch Back to Camera

1. Set `"fallback_mode": false` in config.json
2. Connect camera
3. Restart: `python main.py`
4. Check for green "Live" badge

## ❓ Troubleshooting

| Problem | Solution |
|---------|----------|
| Upload fails | Check image format (JPG/PNG) |
| No detections | Ensure people are visible in image |
| Lights not responding | Verify zones are enabled |
| Can't find upload button | Check dashboard for yellow warning |

## 📊 Status Indicators

- 🟢 **Green "Live"** = Camera working normally
- 🟡 **Yellow "Fallback Mode"** = Using image uploads
- 🔴 **Red "Error"** = System problem

## 📝 Configuration Reference

**Minimal config for fallback:**
```json
{
  "fallback_mode": true,
  "detection": {
    "model": "yolov8n.pt",
    "confidence": 0.5
  },
  "lighting": {
    "platform": "raspberry_pi"
  }
}
```

## 🎯 Use Cases

### Broken Camera
```
Camera stopped working → Enable fallback → 
Upload images from phone → Lights still work!
```

### Testing
```
No camera available → Enable fallback → 
Upload test images → Verify zone logic
```

### Remote Control
```
Away from lab → Upload image via API → 
Trigger lights remotely
```

## 📚 More Help

- Full guide: `docs/camera_fallback_guide.html`
- Implementation details: `docs/fallback_mode_implementation.md`
- Test script: `python test_image_upload.py`

---

**Remember**: Fallback mode is a backup solution. For best results, use a working camera with live feed!
