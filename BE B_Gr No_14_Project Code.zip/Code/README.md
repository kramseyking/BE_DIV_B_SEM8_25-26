# Smart Lighting Control System

A comprehensive zonal lighting control system using computer vision and human detection, designed for college computer labs and similar environments.

## 🌟 Features

### Core Functionality
- **Real-time Human Detection**: Uses YOLO for accurate person detection
- **Zone-based Control**: Define custom lighting zones through intuitive web interface
- **Cross-platform Compatibility**: Works on both laptop (development/demo) and Raspberry Pi (production)
- **Energy Monitoring**: Track consumption and savings in rupees with detailed analytics
- **Responsive Web Dashboard**: Access from any device on the network

### Technical Highlights
- **Performance Optimized**: Prioritizes responsiveness over visual quality
- **Intuitive Zone Definition**: Click-and-draw interface for zone creation
- **Real-time Updates**: WebSocket-based live monitoring
- **Energy Analytics**: Comprehensive usage tracking and cost analysis
- **Manual Override**: Emergency manual control capabilities

## 🚀 Quick Start

### Prerequisites
```bash
# Python 3.8 or higher
python --version

# Install system dependencies (Ubuntu/Raspberry Pi)
sudo apt update
sudo apt install python3-opencv python3-pip

# For Raspberry Pi GPIO (if using actual hardware)
sudo apt install python3-rpi.gpio
```

### Installation
1. **Clone/Download the project**
   ```bash
   cd smart-lighting-system
   ```

2. **Install Python dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure the system**
   ```bash
   # Copy example configuration
   cp config.example.json config.json
   
   # Edit configuration as needed
   nano config.json
   ```

4. **Run the system**
   ```bash
   python main.py
   ```

5. **Access the web interface**
   - Open browser to `http://localhost:5000`
   - Or from any device: `http://[your-ip]:5000`

## 📋 Configuration Guide

### Basic Configuration (`config.json`)

```json
{
  "camera": {
    "source": 0,           // USB camera index or Pi camera
    "width": 640,
    "height": 480,
    "fps": 10,
    "pi_camera": false     // Set true for Raspberry Pi camera
  },
  "lighting": {
    "platform": "laptop",  // "laptop" or "raspberry_pi"
    "gpio_pins": [18, 19, 20, 21], // GPIO pins for lights
    "default_brightness": 80
  },
  "energy": {
    "electricity_rate_per_kwh": 6.5, // Rate in rupees
    "light_power_watts": 15,
    "currency": "₹"
  }
}
```

### Platform-Specific Setup

#### Laptop/Development Mode
- Uses USB camera (source: 0 for default camera)
- Simulated lighting control (no physical lights needed)
- Perfect for testing and demonstration

#### Raspberry Pi Production Mode
- Set `"platform": "raspberry_pi"` in config
- Configure GPIO pins for relay control
- Set `"pi_camera": true` if using Pi camera module
- Ensure proper permissions for GPIO access

## 🎯 Usage Guide

### 1. Zone Definition
1. **Take Snapshot**: Click "Take Snapshot" to capture current camera view
2. **Draw Zones**: 
   - **Polygon Mode**: Click points to define irregular shapes
   - **Rectangle Mode**: Click and drag for rectangular zones
3. **Name & Configure**: Assign names and associate lights with zones
4. **Save**: Zones are automatically saved and persist across restarts

### 2. Light Management
- **Add Lights**: Define lights with power ratings and GPIO pins
- **Zone Assignment**: Associate lights with specific zones
- **Manual Control**: Override automatic control when needed
- **Brightness Control**: (removed) Lights do not support dimming in this version

### 3. Energy Monitoring
- **Real-time Usage**: Monitor current power consumption
- **Daily/Monthly Reports**: View detailed usage analytics
- **Savings Analysis**: Compare with baseline usage patterns
- **Cost Tracking**: Monitor expenses in rupees
- **Export Data**: Download reports in JSON format

### 4. System Monitoring
- **Live Camera Feed**: Real-time view with detection overlays
- **Zone Occupancy**: See which zones are currently occupied
- **System Status**: Monitor camera, lighting, and energy systems
- **Activity Log**: Track recent system events

## 🔧 Advanced Configuration

### Camera Settings
```json
{
  "camera": {
    "source": "/dev/video0",  // Specific camera device
    "width": 1280,            // Higher resolution
    "height": 720,
    "fps": 15,                // Higher frame rate
    "pi_camera": true         // Use Pi camera module
  }
}
```

### Detection Optimization
```json
{
  "detection": {
    "model": "yolov8s.pt",    // Better accuracy (slower)
    "confidence": 0.6,        // Higher confidence threshold
    "device": "cuda",         // GPU acceleration (if available)
    "track_history": 50       // Longer tracking history
  }
}
```

### Lighting Control
```json
{
  "lighting": {
    "platform": "raspberry_pi",
    "gpio_pins": [18, 19, 20, 21, 22, 23, 24, 25],
    "relay_active_low": false,     // Relay logic
    "default_brightness": 100,
    "fade_duration": 0.5          // Smooth transitions
  }
}
```

## 🌐 Network Access

### Local Network Setup
1. **Find IP Address**:
   ```bash
   # Linux/Mac
   ip addr show
   
   # Windows
   ipconfig
   ```

2. **Configure Firewall** (if needed):
   ```bash
   # Ubuntu
   sudo ufw allow 5000
   
   # Windows: Allow port 5000 in Windows Firewall
   ```

3. **Access from Mobile/Other Devices**:
   - Connect to same WiFi network
   - Open browser to `http://[raspberry-pi-ip]:5000`

### Secure Access (Optional)
For production environments, consider:
- Setting up HTTPS with SSL certificates
- Implementing user authentication
- Using a reverse proxy (nginx)
- VPN access for remote monitoring

## 📊 Energy Efficiency Tips

### Maximizing Savings
1. **Optimize Zone Sizes**: Create zones that match actual usage patterns
2. **Adjust Sensitivity**: Fine-tune detection confidence for your environment
3. **Regular Monitoring**: Review energy reports weekly
4. **Manual Override Sparingly**: Use automatic control for best efficiency

### Understanding Metrics
- **Baseline Usage**: Estimated consumption without smart control
- **Actual Usage**: Real measured consumption
- **Savings Percentage**: Efficiency improvement over baseline
- **Cost Analysis**: Financial benefits in rupees

## 🔍 Troubleshooting

### Common Issues

## 🧑‍💻 Developer Notes

Quick notes for contributors and maintainers:

- **Camera Fallback Mode (Image Upload)**:
  - If your camera is malfunctioning, you can enable fallback mode to upload still images for detection
  - Set `"fallback_mode": true` in `config.json`
  - The system will automatically switch to fallback mode if camera initialization fails
  - Use the web dashboard to upload images - the YOLO model will detect people and control lights accordingly
  - Images can be uploaded via the web interface or API endpoint `/api/camera/upload`
  - Perfect backup when Pi camera or USB camera has hardware issues

- Raspberry Pi 5 setup:
  - Install pigpio and enable the daemon:
    ```bash
    sudo apt update
    sudo apt install -y pigpio python3-pip
    sudo systemctl enable --now pigpiod
    pip install gpiozero pigpio RPi.GPIO
    ```
  - In `config.json` set:
    ```json
    "lighting": {
      "platform": "raspberry_pi",
      "gpio_factory": "pigpio",
      "force_simulated": false
    }
    ```

- Development formatting:
  - Install dev requirements: `pip install -r requirements-dev.txt`
  - Format code with the included script (PowerShell): `./scripts/format-code.ps1`
  - Or run locally: `python -m isort . && python -m black .`

- Simulation flag:
  - To run without hardware (desktop), set `"force_simulated": true` in `config.json`.

- Notes:
  - Dimming/brightness support has been removed — all lights are on/off relays.
  - Use `config.example.json` as the base for `config.json`.


**Camera Not Working**
```bash
# Check camera access
ls /dev/video*

# Test camera
python -c "import cv2; cap = cv2.VideoCapture(0); print(cap.isOpened())"

# If camera fails, enable fallback mode in config.json
# Set "fallback_mode": true to use image upload instead
```

**Using Image Upload Fallback Mode**
1. Enable fallback mode in `config.json`:
   ```json
   {
     "fallback_mode": true
   }
   ```
2. Start the system - it will run without camera initialization
3. Open the web dashboard
4. Use the "Upload & Detect" button to upload images
5. The system will detect people in uploaded images and control lights accordingly
6. Great for testing or when camera hardware is broken

**GPIO Permission Issues (Raspberry Pi)**
```bash
# Add user to gpio group
sudo usermod -a -G gpio $USER

# Logout and login again
```

**Performance Issues**
- Reduce camera resolution/FPS in config
- Use lighter YOLO model (`yolov8n.pt`)
- Ensure adequate power supply (especially Pi)

**Network Access Issues**
```bash
# Check if service is running
netstat -tlnp | grep :5000

# Test local access
curl http://localhost:5000/api/status
```

### Debug Mode
Run with debug enabled for detailed logging:
```bash
python main.py --debug
```

Check logs in `smart_lighting.log` for detailed error information.

## 🔄 Updates and Maintenance

### Regular Maintenance
1. **Update Dependencies**: 
   ```bash
   pip install --upgrade -r requirements.txt
   ```

2. **Clean Data**: Periodically clean old energy data
3. **Backup Configuration**: Save `config.json` and `data/` folder
4. **Check Hardware**: Verify camera and lighting connections

### Performance Monitoring
- Monitor CPU/memory usage during operation
- Check disk space for data storage
- Verify network connectivity for web access

## 🤝 Support and Development

### Getting Help
1. **Check Logs**: Always check `smart_lighting.log` first
2. **Test Components**: Use debug mode to isolate issues
3. **Configuration**: Verify all settings in `config.json`

### Contributing
The system is designed to be modular and extensible:
- `src/camera_system.py`: Camera and detection logic
- `src/zone_manager.py`: Zone definition and management
- `src/lighting_system.py`: Light control and GPIO
- `src/energy_monitor.py`: Energy tracking and analytics
- `app.py`: Web application and API

## 📄 License

MIT License - Feel free to use and modify for your needs.

## 🎓 College Lab Specific Notes

### Recommended Setup
- **Raspberry Pi 4B** with at least 4GB RAM
- **Pi Camera Module v2** or **USB webcam**
- **8-channel relay module** for lighting control
- **LED strips or smart bulbs** for zone lighting
- **UPS/Battery backup** for continuous operation

### Integration Ideas
- **Student Access Control**: Integrate with student ID systems
- **Class Schedule Integration**: Automatic scheduling based on timetables
- **Usage Analytics**: Track lab utilization patterns
- **Remote Monitoring**: Allow IT staff to monitor from anywhere

### Safety Considerations
- **Electrical Safety**: Proper wiring and safety switches
- **Emergency Override**: Physical switches for manual control
- **Privacy**: Consider privacy implications of camera monitoring
- **Data Security**: Secure network access and data storage