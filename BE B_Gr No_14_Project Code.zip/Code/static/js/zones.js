// Zone Management JavaScript

class ZoneManager {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.referenceImage = null;
        this.currentPoints = [];
        this.zones = {};
        this.selectedZone = null;
        this.drawingMode = 'polygon';
        this.isDrawing = false;
        this.tempRectStart = null;
        
        this.init();
    }
    
    init() {
        this.setupCanvas();
        this.setupEventListeners();
        this.loadZones();
        this.loadLights();
        this.takeSnapshot();
    }
    
    setupCanvas() {
        this.canvas = document.getElementById('zone-canvas');
        this.ctx = this.canvas.getContext('2d');
        
        // Set up canvas event listeners
        this.canvas.addEventListener('click', (e) => this.handleCanvasClick(e));
        this.canvas.addEventListener('dblclick', (e) => this.handleCanvasDoubleClick(e));
        this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e));
        this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        this.canvas.addEventListener('mouseup', (e) => this.handleMouseUp(e));
    }
    
    setupEventListeners() {
        // Drawing mode selection
        document.querySelectorAll('input[name="drawing-mode"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.drawingMode = e.target.value;
                this.clearCurrentDrawing();
            });
        });
        
        // Control buttons
        document.getElementById('refresh-snapshot').addEventListener('click', () => this.takeSnapshot());
        document.getElementById('create-zone').addEventListener('click', () => this.showCreateZoneModal());
        document.getElementById('clear-drawing').addEventListener('click', () => this.clearCurrentDrawing());
        document.getElementById('undo-point').addEventListener('click', () => this.undoLastPoint());
        
        // Forms
        document.getElementById('create-zone-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.createZone();
        });
        
        document.getElementById('zone-edit-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateSelectedZone();
        });
        
        document.getElementById('delete-zone').addEventListener('click', () => this.deleteSelectedZone());
    }
    
    async takeSnapshot() {
        try {
            const response = await fetch('/api/camera/snapshot');
            if (response.ok) {
                const data = await response.json();
                this.loadReferenceImage(data.image, data.width, data.height);
            } else {
                console.error('Failed to take snapshot');
            }
        } catch (error) {
            console.error('Error taking snapshot:', error);
        }
    }
    
    loadReferenceImage(imageData, width, height) {
        const img = new Image();
        img.onload = () => {
            // Resize canvas to match image
            this.canvas.width = width;
            this.canvas.height = height;
            
            this.referenceImage = img;
            this.redrawCanvas();
        };
        img.src = imageData;
    }
    
    handleCanvasClick(e) {
        if (this.drawingMode === 'polygon') {
            const point = this.getCanvasPoint(e);
            this.currentPoints.push(point);
            this.redrawCanvas();
            this.updateCreateButton();
        }
    }
    
    handleCanvasDoubleClick(e) {
        if (this.drawingMode === 'polygon' && this.currentPoints.length >= 3) {
            // Finish polygon on double-click
            this.finishPolygon();
        }
    }
    
    handleMouseDown(e) {
        if (this.drawingMode === 'rectangle') {
            this.isDrawing = true;
            this.tempRectStart = this.getCanvasPoint(e);
        }
    }
    
    handleMouseMove(e) {
        if (this.drawingMode === 'rectangle' && this.isDrawing && this.tempRectStart) {
            const currentPoint = this.getCanvasPoint(e);
            this.redrawCanvas();
            this.drawTempRectangle(this.tempRectStart, currentPoint);
        }
    }
    
    handleMouseUp(e) {
        if (this.drawingMode === 'rectangle' && this.isDrawing) {
            const endPoint = this.getCanvasPoint(e);
            this.finishRectangle(this.tempRectStart, endPoint);
            this.isDrawing = false;
            this.tempRectStart = null;
        }
    }
    
    getCanvasPoint(e) {
        const rect = this.canvas.getBoundingClientRect();
        const scaleX = this.canvas.width / rect.width;
        const scaleY = this.canvas.height / rect.height;
        
        return {
            x: Math.round((e.clientX - rect.left) * scaleX),
            y: Math.round((e.clientY - rect.top) * scaleY)
        };
    }
    
    finishPolygon() {
        if (this.currentPoints.length >= 3) {
            this.showCreateZoneModal();
        }
    }
    
    finishRectangle(start, end) {
        // Convert rectangle to polygon points
        this.currentPoints = [
            { x: start.x, y: start.y },
            { x: end.x, y: start.y },
            { x: end.x, y: end.y },
            { x: start.x, y: end.y }
        ];
        this.redrawCanvas();
        this.updateCreateButton();
    }
    
    drawTempRectangle(start, end) {
        this.ctx.strokeStyle = '#007bff';
        this.ctx.lineWidth = 2;
        this.ctx.setLineDash([5, 5]);
        this.ctx.strokeRect(start.x, start.y, end.x - start.x, end.y - start.y);
        this.ctx.setLineDash([]);
    }
    
    clearCurrentDrawing() {
        this.currentPoints = [];
        this.redrawCanvas();
        this.updateCreateButton();
    }
    
    undoLastPoint() {
        if (this.currentPoints.length > 0) {
            this.currentPoints.pop();
            this.redrawCanvas();
            this.updateCreateButton();
        }
    }
    
    redrawCanvas() {
        if (!this.referenceImage) return;
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw reference image
        this.ctx.drawImage(this.referenceImage, 0, 0);
        
        // Draw existing zones
        this.drawExistingZones();
        
        // Draw current drawing
        this.drawCurrentPoints();
    }
    
    drawExistingZones() {
        Object.entries(this.zones).forEach(([zoneId, zone]) => {
            if (zone.points && zone.points.length >= 3) {
                this.drawZonePolygon(zone.points, zone.enabled ? '#28a745' : '#6c757d', zone.name);
            }
        });
    }
    
    drawCurrentPoints() {
        if (this.currentPoints.length === 0) return;
        
        // Draw lines between points
        if (this.currentPoints.length > 1) {
            this.ctx.strokeStyle = '#007bff';
            this.ctx.lineWidth = 2;
            this.ctx.beginPath();
            this.ctx.moveTo(this.currentPoints[0].x, this.currentPoints[0].y);
            
            for (let i = 1; i < this.currentPoints.length; i++) {
                this.ctx.lineTo(this.currentPoints[i].x, this.currentPoints[i].y);
            }
            this.ctx.stroke();
        }
        
        // Draw points
        this.currentPoints.forEach((point, index) => {
            this.ctx.fillStyle = '#007bff';
            this.ctx.beginPath();
            this.ctx.arc(point.x, point.y, 4, 0, 2 * Math.PI);
            this.ctx.fill();
            
            // Draw point number
            this.ctx.fillStyle = '#fff';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(index + 1, point.x, point.y + 3);
        });
    }
    
    drawZonePolygon(points, color, name) {
        if (points.length < 3) return;
        
        // Draw filled polygon
        this.ctx.fillStyle = color + '40'; // Add transparency
        this.ctx.strokeStyle = color;
        this.ctx.lineWidth = 2;
        
        this.ctx.beginPath();
        this.ctx.moveTo(points[0].x, points[0].y);
        
        for (let i = 1; i < points.length; i++) {
            this.ctx.lineTo(points[i].x, points[i].y);
        }
        this.ctx.closePath();
        this.ctx.fill();
        this.ctx.stroke();
        
        // Draw zone name at center
        if (name) {
            const centerX = points.reduce((sum, p) => sum + p.x, 0) / points.length;
            const centerY = points.reduce((sum, p) => sum + p.y, 0) / points.length;
            
            this.ctx.fillStyle = '#000';
            this.ctx.font = '14px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(name, centerX, centerY);
        }
    }
    
    updateCreateButton() {
        const button = document.getElementById('create-zone');
        const hasEnoughPoints = this.currentPoints.length >= 3;
        button.disabled = !hasEnoughPoints;
        
        // Update points count in modal
        const pointsCount = document.getElementById('points-count');
        if (pointsCount) {
            pointsCount.textContent = this.currentPoints.length;
        }
    }
    
    showCreateZoneModal() {
        if (this.currentPoints.length < 3) {
            alert('Please draw a zone with at least 3 points first.');
            return;
        }
        
        const modal = new bootstrap.Modal(document.getElementById('zoneCreationModal'));
        document.getElementById('points-count').textContent = this.currentPoints.length;
        modal.show();
    }
    
    async createZone() {
        const name = document.getElementById('new-zone-name').value;
        const lightIds = Array.from(document.getElementById('new-zone-lights').selectedOptions)
                              .map(option => option.value);
        
        try {
            const response = await fetch('/api/zones', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: name,
                    points: this.currentPoints.map(p => [p.x, p.y]),
                    light_ids: lightIds
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                console.log('Zone created:', data.zone_id);
                
                // Clear current drawing
                this.clearCurrentDrawing();
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('zoneCreationModal'));
                modal.hide();
                
                // Reload zones
                this.loadZones();
                
                // Reset form
                document.getElementById('create-zone-form').reset();
                
            } else {
                const error = await response.json();
                alert('Failed to create zone: ' + error.error);
            }
        } catch (error) {
            console.error('Error creating zone:', error);
            alert('Failed to create zone: ' + error.message);
        }
    }
    
    async loadZones() {
        try {
            const response = await fetch('/api/zones');
            if (response.ok) {
                const data = await response.json();
                this.zones = data.zones;
                this.updateZonesList();
                this.updateZoneStats();
                this.redrawCanvas();
            }
        } catch (error) {
            console.error('Error loading zones:', error);
        }
    }
    
    async loadLights() {
        try {
            const response = await fetch('/api/lights');
            if (response.ok) {
                const data = await response.json();
                this.updateLightSelectors(data.lights);
            }
        } catch (error) {
            console.error('Error loading lights:', error);
        }
    }
    
    updateLightSelectors(lights) {
        const selectors = ['new-zone-lights', 'zone-lights'];
        selectors.forEach(selectorId => {
            const select = document.getElementById(selectorId);
            select.innerHTML = '';
            
            Object.entries(lights).forEach(([lightId, light]) => {
                const option = document.createElement('option');
                option.value = lightId;
                option.textContent = light.name;
                select.appendChild(option);
            });
        });
    }
    
    updateZonesList() {
        const container = document.getElementById('zones-list');
        container.innerHTML = '';
        
        Object.entries(this.zones).forEach(([zoneId, zone]) => {
            const zoneElement = this.createZoneListItem(zoneId, zone);
            container.appendChild(zoneElement);
        });
    }
    
    createZoneListItem(zoneId, zone) {
        const div = document.createElement('div');
        div.className = `card mb-2 zone-card ${zone.enabled ? (zone.current_occupancy > 0 ? 'zone-occupied' : 'zone-empty') : 'zone-disabled'}`;
        div.innerHTML = `
            <div class="card-body py-2">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-1">${zone.name}</h6>
                        <small class="text-muted">
                            ${zone.points.length} points | 
                            ${zone.current_occupancy} people |
                            ${zone.light_ids.length} lights
                        </small>
                    </div>
                    <div>
                        <span class="status-indicator ${zone.enabled ? (zone.current_occupancy > 0 ? 'status-online' : 'status-offline') : 'status-warning'}"></span>
                    </div>
                </div>
            </div>
        `;
        
        div.addEventListener('click', () => this.selectZone(zoneId));
        return div;
    }
    
    selectZone(zoneId) {
        this.selectedZone = zoneId;
        const zone = this.zones[zoneId];
        
        // Update zone details panel
        document.getElementById('zone-details').style.display = 'block';
        document.getElementById('edit-zone-name').value = zone.name;
        document.getElementById('zone-enabled').checked = zone.enabled;
        document.getElementById('zone-occupancy').textContent = zone.current_occupancy;
        document.getElementById('zone-last-occupied').textContent = 
            zone.last_occupied ? new Date(zone.last_occupied).toLocaleString() : 'Never';
        document.getElementById('zone-points').textContent = zone.points.length;
        
        // Update light selection
        const lightSelect = document.getElementById('zone-lights');
        Array.from(lightSelect.options).forEach(option => {
            option.selected = zone.light_ids.includes(option.value);
        });
        
        // Highlight selected zone on canvas
        this.redrawCanvas();
        if (zone.points && zone.points.length >= 3) {
            this.drawZonePolygon(zone.points.map(p => ({x: p[0], y: p[1]})), '#ff6b35', zone.name);
        }
    }
    
    async updateSelectedZone() {
        if (!this.selectedZone) return;
        
        const name = document.getElementById('edit-zone-name').value;
        const enabled = document.getElementById('zone-enabled').checked;
        const lightIds = Array.from(document.getElementById('zone-lights').selectedOptions)
                              .map(option => option.value);
        
        try {
            const response = await fetch(`/api/zones/${this.selectedZone}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: name,
                    enabled: enabled,
                    light_ids: lightIds
                })
            });
            
            if (response.ok) {
                this.loadZones();
            } else {
                const error = await response.json();
                alert('Failed to update zone: ' + error.error);
            }
        } catch (error) {
            console.error('Error updating zone:', error);
            alert('Failed to update zone: ' + error.message);
        }
    }
    
    async deleteSelectedZone() {
        if (!this.selectedZone) return;
        
        if (!confirm('Are you sure you want to delete this zone?')) return;
        
        try {
            const response = await fetch(`/api/zones/${this.selectedZone}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                document.getElementById('zone-details').style.display = 'none';
                this.selectedZone = null;
                this.loadZones();
            } else {
                const error = await response.json();
                alert('Failed to delete zone: ' + error.error);
            }
        } catch (error) {
            console.error('Error deleting zone:', error);
            alert('Failed to delete zone: ' + error.message);
        }
    }
    
    updateZoneStats() {
        const totalZones = Object.keys(this.zones).length;
        const activeZones = Object.values(this.zones).filter(z => z.enabled).length;
        const occupiedZones = Object.values(this.zones).filter(z => z.current_occupancy > 0).length;
        const totalPeople = Object.values(this.zones).reduce((sum, z) => sum + z.current_occupancy, 0);
        
        document.getElementById('stats-total-zones').textContent = totalZones;
        document.getElementById('stats-active-zones').textContent = activeZones;
        document.getElementById('stats-occupied-zones').textContent = occupiedZones;
        document.getElementById('stats-total-people').textContent = totalPeople;
    }
}

// Initialize zone manager when page loads
document.addEventListener('DOMContentLoaded', () => {
    new ZoneManager();
});