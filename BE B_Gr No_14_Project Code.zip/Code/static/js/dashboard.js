// Dashboard JavaScript for Smart Lighting System

class SmartLightingDashboard {
    constructor() {
        this.socket = null;
        this.connected = false;
        this.lastUpdateTime = null;
        this.activityLog = [];
        
        this.init();
    }
    
    init() {
        this.initSocketIO();
        this.setupEventListeners();
        this.loadInitialData();
    }
    
    initSocketIO() {
        this.socket = io();
        
        this.socket.on('connect', () => {
            console.log('Connected to server');
            this.connected = true;
            this.hideConnectionModal();
            this.showConnectionStatus(true);
            this.requestUpdate();
        });
        
        this.socket.on('disconnect', () => {
            console.log('Disconnected from server');
            this.connected = false;
            this.showConnectionStatus(false);
            this.showConnectionModal();
        });
        
        this.socket.on('system_update', (data) => {
            this.handleSystemUpdate(data);
        });
        
        // Show connection modal initially
        this.showConnectionModal();
    }
    
    setupEventListeners() {
        // Auto control toggle
        document.getElementById('auto-control').addEventListener('change', (e) => {
            this.toggleAutoControl(e.target.checked);
        });
        
        // Clear overrides button
        document.getElementById('clear-overrides').addEventListener('click', () => {
            this.clearManualOverrides();
        });
        
        // Refresh camera button
        document.getElementById('refresh-camera').addEventListener('click', () => {
            this.refreshCamera();
        });
        
        // Request updates every 5 seconds
        setInterval(() => {
            if (this.connected) {
                this.requestUpdate();
            }
        }, 5000);
    }
    
    async loadInitialData() {
        try {
            const response = await fetch('/api/status');
            if (response.ok) {
                const data = await response.json();
                this.updateSystemStatus(data);
            }
        } catch (error) {
            console.error('Failed to load initial data:', error);
        }
    }
    
    requestUpdate() {
        if (this.socket && this.connected) {
            this.socket.emit('request_update');
        }
    }
    
    handleSystemUpdate(data) {
        console.log('System update received:', data);
        this.lastUpdateTime = new Date();
        
        // Update dashboard metrics
        this.updateDashboardMetrics(data);
        
        // Update detailed views
        this.updateZoneOccupancy(data.zones.zone_data || data.zones);
        this.updateLightStates(data.lights.light_data || data.lights);
        this.updateEnergyData(data.energy);
        this.addActivityLog(data);
    }
    
    updateDashboardMetrics(data) {
        // Update zone metrics
        if (data.zones) {
            if (data.zones.total_zones !== undefined) {
                document.getElementById('total-zones').textContent = data.zones.total_zones;
            }
        }
        
        // Update people count from camera data
        if (data.camera && data.camera.human_count !== undefined) {
            document.getElementById('people-count').textContent = data.camera.human_count;
            this.updateCameraStatus(data.camera.has_frame);
        }
        
        // Update lighting metrics  
        if (data.lights && data.lights.lights_on !== undefined) {
            document.getElementById('active-lights').textContent = data.lights.lights_on;
        }
        
        // Update energy metrics
        if (data.energy && data.energy.current_power !== undefined) {
            document.getElementById('current-power').textContent = Math.round(data.energy.current_power);
        }
    }
    
    updateSystemStatus(data) {
        // Use the same updateDashboardMetrics method for consistency
        this.updateDashboardMetrics(data);
    }
    
    updateZoneOccupancy(zones) {
        const container = document.getElementById('zone-occupancy');
        container.innerHTML = '';
        
        Object.entries(zones).forEach(([zoneId, zoneData]) => {
            const zoneCard = this.createZoneCard(zoneId, zoneData);
            container.appendChild(zoneCard);
        });
    }
    
    createZoneCard(zoneId, zoneData) {
        const card = document.createElement('div');
        card.className = 'col-md-6 col-lg-4 mb-3';
        
        const isOccupied = zoneData.occupancy > 0;
        const statusClass = isOccupied ? 'zone-occupied' : 'zone-empty';
        
        card.innerHTML = `
            <div class="card ${statusClass}">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Zone ${zoneId.substring(0, 8)}</h6>
                            <p class="card-text mb-0">
                                <i class="bi bi-people-fill"></i> ${zoneData.occupancy} people
                            </p>
                            ${zoneData.last_occupied ? `
                                <small class="text-muted">
                                    Last: ${this.formatTimestamp(zoneData.last_occupied)}
                                </small>
                            ` : ''}
                        </div>
                        <div class="text-end">
                            <span class="status-indicator ${isOccupied ? 'status-online' : 'status-offline'}"></span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        return card;
    }
    
    updateLightStates(lights) {
        // If lights is already processed with summary data, no need to count manually
        // This method is for updating detailed light views if needed
        if (lights && typeof lights === 'object' && !lights.light_data) {
            // This is raw light data, count manually for fallback
            let lightsOn = 0;
            Object.values(lights).forEach(light => {
                if (light.is_on) lightsOn++;
            });
            document.getElementById('active-lights').textContent = lightsOn;
        }
        // If lights has light_data structure, the count is handled in updateDashboardMetrics
    }
    
    updateEnergyData(energy) {
        if (energy.current_power !== undefined) {
            document.getElementById('current-power').textContent = Math.round(energy.current_power);
        }
        
        if (energy.daily_usage) {
            const usage = energy.daily_usage;
            document.getElementById('today-kwh').textContent = `${usage.total_kwh.toFixed(2)} kWh`;
            document.getElementById('today-cost').textContent = `${usage.currency} ${usage.total_cost.toFixed(2)}`;
        }
        
        if (energy.savings) {
            const savings = energy.savings;
            document.getElementById('savings-kwh').textContent = `${savings.savings_kwh.toFixed(2)} kWh`;
            document.getElementById('savings-cost').textContent = `${savings.currency} ${savings.savings_cost.toFixed(2)}`;
            
            const efficiency = Math.round(savings.savings_percentage);
            document.getElementById('efficiency-percent').textContent = efficiency;
            document.getElementById('efficiency-bar').style.width = `${Math.min(efficiency, 100)}%`;
        }
    }
    
    addActivityLog(data) {
        const logContainer = document.getElementById('activity-log');
        const timestamp = new Date().toLocaleTimeString();
        
        // Create activity items based on changes
        const activities = [];
        
        // Check for zone occupancy changes
        Object.entries(data.zones).forEach(([zoneId, zoneData]) => {
            if (zoneData.occupancy > 0) {
                activities.push({
                    type: 'zone-occupied',
                    message: `Zone ${zoneId.substring(0, 8)} occupied (${zoneData.occupancy} people)`,
                    timestamp: timestamp
                });
            }
        });
        
        // Check for light state changes
        Object.entries(data.lights).forEach(([lightId, lightData]) => {
            if (lightData.is_on) {
                activities.push({
                    type: 'light-on',
                    message: `Light ${lightId.substring(0, 8)} turned ON`,
                    timestamp: timestamp
                });
            }
        });
        
        // Add new activities to log
        activities.forEach(activity => {
            this.activityLog.unshift(activity);
            
            const activityElement = document.createElement('div');
            activityElement.className = `activity-item activity-${activity.type}`;
            activityElement.innerHTML = `
                <div class="d-flex justify-content-between">
                    <span>${activity.message}</span>
                    <small>${activity.timestamp}</small>
                </div>
            `;
            
            logContainer.insertBefore(activityElement, logContainer.firstChild);
        });
        
        // Keep only last 20 activities
        while (logContainer.children.length > 20) {
            logContainer.removeChild(logContainer.lastChild);
        }
        
        // Keep array in sync
        this.activityLog = this.activityLog.slice(0, 20);
    }
    
    async toggleAutoControl(enabled) {
        try {
            // This would typically send a request to enable/disable auto control
            console.log(`Auto control ${enabled ? 'enabled' : 'disabled'}`);
            
            // Add to activity log
            this.addActivityLog({
                zones: {},
                lights: {},
                energy: {}
            });
            
        } catch (error) {
            console.error('Failed to toggle auto control:', error);
        }
    }
    
    async clearManualOverrides() {
        try {
            // This would send a request to clear all manual overrides
            console.log('Clearing manual overrides');
            
            // Show loading state
            const button = document.getElementById('clear-overrides');
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Clearing...';
            button.disabled = true;
            
            // Simulate API call
            setTimeout(() => {
                button.innerHTML = originalText;
                button.disabled = false;
                
                // Add to activity log
                this.addActivityLog({
                    zones: {},
                    lights: {},
                    energy: {}
                });
            }, 1000);
            
        } catch (error) {
            console.error('Failed to clear manual overrides:', error);
        }
    }
    
    refreshCamera() {
        const videoFeed = document.getElementById('video-feed');
        const refreshButton = document.getElementById('refresh-camera');
        
        // Show loading state
        refreshButton.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Refreshing...';
        refreshButton.disabled = true;
        
        // Force reload video feed
        const timestamp = new Date().getTime();
        videoFeed.src = `/video_feed?t=${timestamp}`;
        
        // Reset button after 2 seconds
        setTimeout(() => {
            refreshButton.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Refresh';
            refreshButton.disabled = false;
        }, 2000);
    }
    
    updateCameraStatus(hasFrame) {
        const statusElement = document.getElementById('camera-status');
        if (hasFrame) {
            statusElement.textContent = 'Connected';
            statusElement.className = 'badge bg-success';
        } else {
            statusElement.textContent = 'No Signal';
            statusElement.className = 'badge bg-danger';
        }
    }
    
    showConnectionStatus(connected) {
        // Update connection indicators throughout the UI
        const indicators = document.querySelectorAll('.connection-indicator');
        indicators.forEach(indicator => {
            indicator.className = `status-indicator ${connected ? 'status-online' : 'status-offline'}`;
        });
    }
    
    showConnectionModal() {
        const modal = new bootstrap.Modal(document.getElementById('connectionModal'));
        modal.show();
    }
    
    hideConnectionModal() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('connectionModal'));
        if (modal) {
            modal.hide();
        }
    }
    
    formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleTimeString();
    }
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', () => {
    new SmartLightingDashboard();
});