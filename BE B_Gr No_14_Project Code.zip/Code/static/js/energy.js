// Energy Analytics JavaScript

class EnergyAnalytics {
    constructor() {
        this.charts = {};
        this.currentPeriod = 'day';
        this.currentDate = new Date();
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.loadInitialData();
        this.chartsEnabled = typeof Chart !== "undefined";
        if (this.chartsEnabled) {
            this.setupCharts();
        } else {
            this.showChartFallback();
        }
        this.startRealTimeUpdates();
    }
    
    setupEventListeners() {
        // Time period selection
        document.querySelectorAll('input[name="time-period"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.currentPeriod = e.target.value;
                this.loadEnergyData();
            });
        });
        
        // Daily period selector
        document.getElementById('daily-period').addEventListener('change', (e) => {
            this.loadDailyChart(parseInt(e.target.value));
        });
        
        // Custom date selector
        document.getElementById('custom-date').addEventListener('change', (e) => {
            this.currentDate = new Date(e.target.value);
            this.loadEnergyData();
        });
        
        // Refresh data button
        document.getElementById('refresh-data').addEventListener('click', () => {
            this.loadEnergyData();
        });
        
        // Settings save button
        document.getElementById('save-settings').addEventListener('click', () => {
            this.saveSettings();
        });
        
        // Export buttons
        document.getElementById('export-daily').addEventListener('click', () => this.exportData('daily'));
        document.getElementById('export-monthly').addEventListener('click', () => this.exportData('monthly'));
        document.getElementById('export-raw').addEventListener('click', () => this.exportData('raw'));
    }
    
    async loadInitialData() {
        try {
            // Load today's data
            const todayResponse = await fetch('/api/energy/daily');
            if (todayResponse.ok) {
                const todayData = await todayResponse.json();
                this.updateTodayOverview(todayData);
            }
            
            // Load savings data
            const savingsResponse = await fetch('/api/energy/savings?days=30');
            if (savingsResponse.ok) {
                const savingsData = await savingsResponse.json();
                this.updateSavingsOverview(savingsData);
            }
            
            // Load current power
            const statusResponse = await fetch('/api/status');
            if (statusResponse.ok) {
                const statusData = await statusResponse.json();
                this.updateCurrentPower(statusData.energy?.current_power || 0);
            }
            
        } catch (error) {
            console.error('Error loading initial data:', error);
        }
    }
    
    setupCharts() {
        this.setupDailyUsageChart();
        this.setupHourlyPatternChart();
        this.setupSavingsChart();
    }

    showChartFallback() {
        const message = "Charts unavailable offline. Connect to the internet or add Chart.js locally.";
        ["dailyUsageChart", "hourlyPatternChart", "savingsChart"].forEach((id) => {
            const canvas = document.getElementById(id);
            if (canvas && canvas.parentElement) {
                const note = document.createElement("div");
                note.className = "chart-fallback-message";
                note.textContent = message;
                canvas.parentElement.appendChild(note);
            }
        });
    }
    
    setupDailyUsageChart() {
        const ctx = document.getElementById('dailyUsageChart').getContext('2d');
        
        this.charts.dailyUsage = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Energy Usage (kWh)',
                    data: [],
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.1)',
                    tension: 0.1,
                    fill: true
                }, {
                    label: 'Cost (₹)',
                    data: [],
                    borderColor: 'rgb(255, 99, 132)',
                    backgroundColor: 'rgba(255, 99, 132, 0.1)',
                    tension: 0.1,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Energy (kWh)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Cost (₹)'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                },
                plugins: {
                    legend: {
                        display: true
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                }
            }
        });
        
        this.loadDailyChart(7);
    }
    
    setupHourlyPatternChart() {
        const ctx = document.getElementById('hourlyPatternChart').getContext('2d');
        
        this.charts.hourlyPattern = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Array.from({length: 24}, (_, i) => `${i}:00`),
                datasets: [{
                    label: 'Average Usage (Wh)',
                    data: new Array(24).fill(0),
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Usage (Wh)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Hour of Day'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
        
        this.loadHourlyPattern();
    }
    
    setupSavingsChart() {
        const ctx = document.getElementById('savingsChart').getContext('2d');
        
        this.charts.savings = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Actual Usage', 'Energy Saved'],
                datasets: [{
                    data: [0, 0],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.8)',
                        'rgba(75, 192, 192, 0.8)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(75, 192, 192, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                return `${label}: ${value.toFixed(2)} kWh`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    async loadDailyChart(days) {
        try {
            if (!this.chartsEnabled) {
                return;
            }
            const promises = [];
            const dates = [];
            const now = new Date();
            
            // Generate date range
            for (let i = days - 1; i >= 0; i--) {
                const date = new Date(now);
                date.setDate(date.getDate() - i);
                dates.push(date.toISOString().split('T')[0]);
                promises.push(fetch(`/api/energy/daily?date=${date.toISOString().split('T')[0]}`));
            }
            
            const responses = await Promise.all(promises);
            const data = await Promise.all(responses.map(r => r.json()));
            
            const usageData = data.map(d => d.total_kwh || 0);
            const costData = data.map(d => d.total_cost || 0);
            const labels = dates.map(date => new Date(date).toLocaleDateString('en-IN', { 
                month: 'short', 
                day: 'numeric' 
            }));
            
            this.charts.dailyUsage.data.labels = labels;
            this.charts.dailyUsage.data.datasets[0].data = usageData;
            this.charts.dailyUsage.data.datasets[1].data = costData;
            this.charts.dailyUsage.update();
            
        } catch (error) {
            console.error('Error loading daily chart:', error);
        }
    }
    
    async loadHourlyPattern() {
        try {
            if (!this.chartsEnabled) {
                return;
            }
            const response = await fetch('/api/energy/patterns?days=7');
            if (response.ok) {
                const data = await response.json();
                const hourlyData = new Array(24).fill(0);
                
                // Fill hourly data
                Object.entries(data.hourly_usage || {}).forEach(([hour, usage]) => {
                    hourlyData[parseInt(hour)] = usage;
                });
                
                this.charts.hourlyPattern.data.datasets[0].data = hourlyData;
                this.charts.hourlyPattern.update();
            }
        } catch (error) {
            console.error('Error loading hourly pattern:', error);
        }
    }
    
    async loadEnergyData() {
        try {
            let endpoint = '/api/energy/daily';
            let params = '';
            
            switch (this.currentPeriod) {
                case 'day':
                    params = `?date=${this.currentDate.toISOString().split('T')[0]}`;
                    break;
                case 'week':
                    endpoint = '/api/energy/weekly';
                    params = `?start_date=${this.currentDate.toISOString().split('T')[0]}`;
                    break;
                case 'month':
                    endpoint = '/api/energy/monthly';
                    params = `?year=${this.currentDate.getFullYear()}&month=${this.currentDate.getMonth() + 1}`;
                    break;
            }
            
            const response = await fetch(endpoint + params);
            if (response.ok) {
                const data = await response.json();
                this.updateEnergyDisplay(data);
            }
        } catch (error) {
            console.error('Error loading energy data:', error);
        }
    }
    
    updateTodayOverview(data) {
        document.getElementById('today-usage').textContent = `${data.total_kwh.toFixed(2)} kWh`;
        document.getElementById('today-cost').textContent = `${data.currency} ${data.total_cost.toFixed(2)}`;
    }
    
    updateSavingsOverview(data) {
        document.getElementById('monthly-savings').textContent = `${data.currency} ${data.savings_cost.toFixed(2)}`;
        document.getElementById('savings-kwh').textContent = `${data.savings_kwh.toFixed(2)} kWh saved`;
        document.getElementById('efficiency-percent').textContent = `${Math.round(data.savings_percentage)}%`;
        
        // Update savings breakdown
        document.getElementById('baseline-usage').textContent = `${data.baseline_kwh.toFixed(2)} kWh`;
        document.getElementById('actual-usage').textContent = `${data.actual_kwh.toFixed(2)} kWh`;
        document.getElementById('total-savings').textContent = `${data.savings_kwh.toFixed(2)} kWh`;
        document.getElementById('baseline-cost').textContent = `${data.currency} ${(data.baseline_kwh * 6.5).toFixed(2)}`;
        document.getElementById('actual-cost').textContent = `${data.currency} ${(data.actual_kwh * 6.5).toFixed(2)}`;
        document.getElementById('money-saved').textContent = `${data.currency} ${data.savings_cost.toFixed(2)}`;
        document.getElementById('savings-percentage').textContent = `${Math.round(data.savings_percentage)}%`;
        
        if (this.chartsEnabled) {
            this.charts.savings.data.datasets[0].data = [data.actual_kwh, data.savings_kwh];
            this.charts.savings.update();
        }
    }
    
    updateCurrentPower(power) {
        document.getElementById('current-power').textContent = `${Math.round(power)} W`;
    }
    
    updateEnergyDisplay(data) {
        // This would update the display based on the selected time period
        console.log('Energy data for', this.currentPeriod, ':', data);
    }
    
    startRealTimeUpdates() {
        // Update current power every 10 seconds
        setInterval(async () => {
            try {
                const response = await fetch('/api/status');
                if (response.ok) {
                    const data = await response.json();
                    this.updateCurrentPower(data.energy?.current_power || 0);
                }
            } catch (error) {
                console.error('Error updating real-time data:', error);
            }
        }, 10000);
    }
    
    async saveSettings() {
        const rate = parseFloat(document.getElementById('electricity-rate').value);
        const baselineHours = parseInt(document.getElementById('baseline-hours').value);
        
        // This would typically save to the server
        console.log('Saving settings:', { rate, baselineHours });
        
        // Show success message
        const button = document.getElementById('save-settings');
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="bi bi-check"></i> Saved!';
        button.className = 'btn btn-success btn-sm w-100';
        
        setTimeout(() => {
            button.innerHTML = originalText;
            button.className = 'btn btn-success btn-sm w-100';
        }, 2000);
    }
    
    async exportData(type) {
        try {
            let endpoint = '';
            let filename = '';
            
            switch (type) {
                case 'daily':
                    endpoint = '/api/energy/daily';
                    filename = `daily_energy_${new Date().toISOString().split('T')[0]}.json`;
                    break;
                case 'monthly':
                    endpoint = '/api/energy/monthly';
                    filename = `monthly_energy_${new Date().getFullYear()}_${new Date().getMonth() + 1}.json`;
                    break;
                case 'raw':
                    endpoint = '/api/energy/patterns?days=30';
                    filename = `energy_data_${new Date().toISOString().split('T')[0]}.json`;
                    break;
            }
            
            const response = await fetch(endpoint);
            if (response.ok) {
                const data = await response.json();
                
                // Create and download file
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            }
        } catch (error) {
            console.error('Error exporting data:', error);
            alert('Failed to export data: ' + error.message);
        }
    }
}

// Initialize energy analytics when page loads
document.addEventListener('DOMContentLoaded', () => {
    new EnergyAnalytics();
});