#!/usr/bin/env python3
"""
Fix script to resolve dashboard and lighting issues
"""

import json
import os
from datetime import datetime


def fix_auto_control():
    """Enable auto control in lights.json"""
    lights_file = "data/lights.json"

    if os.path.exists(lights_file):
        with open(lights_file, "r") as f:
            data = json.load(f)

        # Enable auto control
        data["auto_control_enabled"] = True

        # Clear all manual overrides
        data["manual_overrides"] = {}

        # Clear manual override flags on individual lights
        for light_id, light_data in data["lights"].items():
            light_data["manual_override"] = False

        # Update save timestamp
        data["saved_at"] = datetime.now().isoformat()

        with open(lights_file, "w") as f:
            json.dump(data, f, indent=2)

        print("✅ Fixed auto control and cleared manual overrides")
    else:
        print("❌ lights.json not found")


def fix_zone_light_associations():
    """Fix bidirectional zone-light associations"""
    zones_file = "zones.json"
    lights_file = "data/lights.json"

    if not (os.path.exists(zones_file) and os.path.exists(lights_file)):
        print("❌ Required files not found")
        return

    # Load data
    with open(zones_file, "r") as f:
        zones_data = json.load(f)

    with open(lights_file, "r") as f:
        lights_data = json.load(f)

    # Build zone -> light mapping from light -> zone data
    zone_to_lights = {}
    for light_id, light_data in lights_data["lights"].items():
        for zone_id in light_data.get("zone_ids", []):
            if zone_id not in zone_to_lights:
                zone_to_lights[zone_id] = []
            zone_to_lights[zone_id].append(light_id)

    # Update zones with light associations
    for zone_id, zone_data in zones_data["zones"].items():
        zone_data["light_ids"] = zone_to_lights.get(zone_id, [])

    # Update save timestamp
    zones_data["saved_at"] = datetime.now().isoformat()

    # Save updated zones
    with open(zones_file, "w") as f:
        json.dump(zones_data, f, indent=2)

    print("✅ Fixed bidirectional zone-light associations")

    # Show the associations
    for zone_id, zone_data in zones_data["zones"].items():
        zone_name = zone_data["name"]
        light_count = len(zone_data["light_ids"])
        print(f"  Zone '{zone_name}': {light_count} lights assigned")


if __name__ == "__main__":
    print("🔧 Fixing Smart Lighting Issues...")
    print()

    fix_auto_control()
    fix_zone_light_associations()

    print()
    print("✅ All fixes applied! Restart the application to see changes.")
