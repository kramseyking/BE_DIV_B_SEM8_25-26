# Energy Report

## Methods
Data were extracted from the system logs; only events labeled `usage` were used since they contain explicit `energy_wh` values. Summary statistics are reported in Watt-hours (Wh).

## Summary Statistics
| Metric | Value |
|---:|---:|
| Total energy (Wh) | 1935.669727 |
| Number of usage events | 8146 |
| Mean energy per event (Wh) | 0.237622 |
| Median energy per event (Wh) | 0.002099 |
| Min energy per event (Wh) | 0.000003 |
| Max energy per event (Wh) | 1704.108761 |

## Top 10 Lights by Total Energy (Wh)
| Rank | Light ID | Usage events | Total energy (Wh) |
|---:|---|---:|---:|
| 1 | 5dc781d4-852d-41a7-b63a-b515157dfd80 | 3764 | 1755.548274 |
| 2 | d7441df5-164d-472a-bb43-dc5447d43b93 | 2193 | 103.803639 |
| 3 | e35839ed-e01a-4a31-bff8-07fade505c4f | 2189 | 76.317814 |

## Daily Energy (sample)
| Date | Total energy (Wh) |
|---|---:|
| 2025-09-12 | 114.898598 |
| 2025-09-18 | 1820.771130 |
