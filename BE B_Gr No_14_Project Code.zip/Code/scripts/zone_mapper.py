#!/usr/bin/env python3
"""
Interactive zone mapper.

Captures a reference frame from the Pi camera (Picamera2 cam0) and allows the
user to draw polygon points for each zone found in `zones.json`. After
confirmation the zones file is updated (backup created as zones.json.bak).

Controls (keyboard while viewing each zone):
  - Left click: add point
  - r: reset points for current zone
  - c: confirm/save current zone and move to next
  - q: quit without saving

Run on Pi:
  python3 scripts/zone_mapper.py --zones zones.json --out zones.json

"""
import argparse
import json
import os
import shutil
import sys
import time
from typing import List, Tuple

import cv2
import numpy as np

try:
    from picamera2 import Picamera2
except Exception:
    print("picamera2 is required for this script. Install python3-picamera2 on the Pi.")
    raise


def capture_reference_frame(width: int, height: int):
    try:
        try:
            picam2 = Picamera2(camera_num=0)
        except TypeError:
            picam2 = Picamera2()
        config = picam2.create_still_configuration(main={"size": (width, height)})
        picam2.configure(config)
        picam2.start()
        time.sleep(0.5)
        frame = picam2.capture_array()
        picam2.stop()
        # convert RGB->BGR for OpenCV
        if frame is not None:
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        return frame
    except Exception as e:
        print(f"Failed to capture reference frame: {e}")
        return None


def draw_polygon(img: np.ndarray, points: List[Tuple[int, int]]):
    out = img.copy()
    for p in points:
        cv2.circle(out, p, 4, (0, 255, 0), -1)
    if len(points) > 1:
        cv2.polylines(out, [np.array(points, dtype=np.int32)], isClosed=False, color=(0, 255, 0), thickness=2)
    return out


def mapper_loop(frame: np.ndarray, zones_data: dict, save_file: str):
    if frame is None:
        print("No frame to map against. Aborting.")
        return False

    window_name = "Zone Mapper - Left click to add points. Press 'c' to confirm, 'r' to reset, 'q' to quit"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

    zone_ids = list(zones_data.get("zones", {}).keys())
    if not zone_ids:
        print("No zones found in zones file.")
        return False

    for zid in zone_ids:
        zone = zones_data["zones"][zid]
        name = zone.get("name", zid)
        existing = zone.get("points", [])

        pts: List[Tuple[int, int]] = [(int(p[0]), int(p[1])) for p in existing]

        drawing = True

        def on_mouse(event, x, y, flags, param):
            nonlocal pts
            if event == cv2.EVENT_LBUTTONDOWN:
                pts.append((x, y))

        cv2.setMouseCallback(window_name, on_mouse)

        while drawing:
            disp = frame.copy()
            # draw existing polygon lightly
            if existing:
                pts_existing = [(int(p[0]), int(p[1])) for p in existing]
                if pts_existing:
                    cv2.polylines(disp, [np.array(pts_existing, dtype=np.int32)], True, (255, 0, 0), 2)

            disp = draw_polygon(disp, pts)
            overlay = disp.copy()
            cv2.putText(overlay, f"Zone: {name} ({zid})", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
            cv2.putText(overlay, "Left-click: add point | r: reset | c: confirm | q: quit (no save)", (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.imshow(window_name, overlay)
            key = cv2.waitKey(20) & 0xFF
            if key == ord("r"):
                pts = []
            elif key == ord("c"):
                # need at least 3 points
                if len(pts) < 3:
                    print("Please define at least 3 points for a polygon")
                    continue
                # save points
                zones_data["zones"][zid]["points"] = [[int(x), int(y)] for x, y in pts]
                drawing = False
            elif key == ord("q"):
                print("Quitting without saving")
                cv2.destroyAllWindows()
                return False

    cv2.destroyAllWindows()

    # Backup existing file
    if os.path.exists(save_file):
        shutil.copy2(save_file, save_file + ".bak")

    with open(save_file, "w") as f:
        json.dump(zones_data, f, indent=2)

    print(f"Saved updated zones to {save_file} (backup at {save_file}.bak)")
    return True


def main():
    parser = argparse.ArgumentParser(description="Interactive zone mapper using Picamera2")
    parser.add_argument("--zones", default="zones.json", help="zones file to load")
    parser.add_argument("--out", default=None, help="output zones file (defaults to --zones)")
    parser.add_argument("--width", type=int, default=1280, help="capture width")
    parser.add_argument("--height", type=int, default=720, help="capture height")
    args = parser.parse_args()

    zones_file = args.zones
    out_file = args.out or zones_file

    if not os.path.exists(zones_file):
        print(f"Zones file not found: {zones_file}")
        sys.exit(1)

    with open(zones_file, "r") as f:
        zones_data = json.load(f)

    frame = capture_reference_frame(args.width, args.height)
    if frame is None:
        sys.exit(1)

    ok = mapper_loop(frame, zones_data, out_file)
    if not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
