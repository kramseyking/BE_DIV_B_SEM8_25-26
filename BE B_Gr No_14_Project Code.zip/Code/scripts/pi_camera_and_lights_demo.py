#!/usr/bin/env python3
"""
Demo: control four lights via GPIO and capture images with picamera2.

This script cycles each configured light on the Pi, captures a still with
picamera2 while that light is on, then turns it off. It's intended for
verification/testing of wiring and camera operation.

Wiring assumptions (see README below for details):
  - Using BCM GPIO pins: 17, 27, 22, 23 (one per light)
  - If lights are mains AC: use a 4-channel relay module (optically-isolated)
    and wire relay input to the GPIO pin. Relay VCC to 5V, GND to Pi GND.
  - If lights are low-voltage DC (e.g., 12V LEDs): use logic-level N-MOSFETs
    (e.g., IRLZ44N or IRLZ34) or a MOSFET driver board; power the lights from
    the external supply and share grounds with the Pi.

Run on Raspberry Pi with picamera2 installed. Example:
  python3 scripts/pi_camera_and_lights_demo.py --outdir /home/pi/demo_captures --cycles 2 --interval 1.5

"""
import argparse
import datetime
import os
import time

from picamera2 import Picamera2

# GPIO imports are performed lazily in setup_gpio so the script can run
# in a simulated mode or on systems without GPIO libraries installed.
GPIO_LIB = None
USE_GPIOZERO = False


# Default BCM pins for three lights -- change if you prefer other pins
# GPIO 23 excluded per user request
LIGHT_PINS = [17, 27, 22]


def setup_gpio(pins, simulate=False):
    """Initialize GPIO controllers.

    If simulate=True, returns a dummy controller and does not import GPIO libs.
    """
    if simulate:
        class DummyLED:
            def __init__(self, p):
                self.pin = p
            def on(self):
                print(f"[SIM] LED on pin {self.pin} -> ON")
            def off(self):
                print(f"[SIM] LED on pin {self.pin} -> OFF")
            def close(self):
                pass

        leds = [DummyLED(p) for p in pins]
        return leds

    # Lazy-import GPIO libraries to avoid import errors on non-Pi systems
    global GPIO_LIB, USE_GPIOZERO
    try:
        import RPi.GPIO as GPIO
        GPIO_LIB = 'RPIGPIO'
    except Exception:
        try:
            from gpiozero import LED
            GPIO_LIB = 'GPIOZERO'
            USE_GPIOZERO = True
        except Exception:
            GPIO_LIB = None

    if GPIO_LIB == 'RPIGPIO':
        import RPi.GPIO as GPIO
        GPIO.setmode(GPIO.BCM)
        for p in pins:
            GPIO.setup(p, GPIO.OUT)
            GPIO.output(p, GPIO.LOW)
        return None
    elif GPIO_LIB == 'GPIOZERO':
        from gpiozero import LED
        leds = [LED(p) for p in pins]
        for led in leds:
            led.off()
        return leds
    else:
        raise RuntimeError('No GPIO library available. Install RPi.GPIO or gpiozero on the Pi, or run with --simulate-gpio')


def set_light_state(pins_or_leds, idx, on):
    if GPIO_LIB == 'RPIGPIO':
        import RPi.GPIO as GPIO
        pin = LIGHT_PINS[idx]
        GPIO.output(pin, GPIO.HIGH if on else GPIO.LOW)
    else:
        leds = pins_or_leds
        if leds is None:
            # No GPIO controller (should not happen unless simulate=False and no libs)
            return
        if on:
            leds[idx].on()
        else:
            leds[idx].off()


def cleanup_gpio(pins_or_leds):
    # If we used simulated LEDs, pins_or_leds will be a list of dummy LEDs
    try:
        if isinstance(pins_or_leds, list):
            for led in pins_or_leds:
                try:
                    led.off()
                    if hasattr(led, 'close'):
                        led.close()
                except Exception:
                    pass
            return
    except Exception:
        pass

    if GPIO_LIB == 'RPIGPIO':
        try:
            import RPi.GPIO as GPIO
            for p in LIGHT_PINS:
                try:
                    GPIO.output(p, GPIO.LOW)
                except Exception:
                    pass
            GPIO.cleanup()
        except Exception:
            pass
    elif GPIO_LIB == 'GPIOZERO':
        for led in pins_or_leds:
            try:
                led.off()
                led.close()
            except Exception:
                pass


def capture_image(picam2, outpath):
    img = picam2.capture_image()
    img.save(outpath, format='JPEG')


def main():
    parser = argparse.ArgumentParser(description='Demo: cycle 4 lights and capture images with picamera2')
    parser.add_argument('--outdir', default='demo_captures', help='output directory for captured images')
    parser.add_argument('--cycles', type=int, default=1, help='how many times to cycle all lights')
    parser.add_argument('--interval', type=float, default=1.0, help='seconds between each light cycle')
    parser.add_argument('--width', type=int, default=1280, help='capture width')
    parser.add_argument('--height', type=int, default=720, help='capture height')
    parser.add_argument('--simulate-gpio', action='store_true', help='Do not access GPIO; simulate light toggles')
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    pins_or_leds = setup_gpio(LIGHT_PINS, simulate=args.simulate_gpio)

    try:
        picam2 = Picamera2(camera_num=0)
    except TypeError:
        picam2 = Picamera2()
    config = picam2.create_still_configuration(main={'size': (args.width, args.height)})
    picam2.configure(config)

    try:
        picam2.start()
        time.sleep(0.5)  # warm-up

        for cycle in range(args.cycles):
            for i in range(len(LIGHT_PINS)):
                print(f"Cycle {cycle+1}/{args.cycles}: turning ON light {i+1} (GPIO {LIGHT_PINS[i]})")
                set_light_state(pins_or_leds, i, True)
                # short settle time so the light has reached steady state
                time.sleep(0.5)

                ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                fname = f"light{i+1}_{ts}_c{cycle+1}.jpg"
                outpath = os.path.join(args.outdir, fname)
                try:
                    capture_image(picam2, outpath)
                    print(f"Captured image for light {i+1}: {outpath}")
                except Exception as e:
                    print(f"Failed to capture image: {e}")

                print(f"Turning OFF light {i+1}")
                set_light_state(pins_or_leds, i, False)

                time.sleep(args.interval)

    except KeyboardInterrupt:
        print("Interrupted by user")
    finally:
        try:
            picam2.stop()
        except Exception:
            pass
        cleanup_gpio(pins_or_leds)


if __name__ == '__main__':
    main()
