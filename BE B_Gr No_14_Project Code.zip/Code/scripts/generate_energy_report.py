#!/usr/bin/env python3
"""
Light energy report generator.

Reads `data/energy_data.json` (expected format: {"records": [ ... ]}) and
produces:
- report.md        (Markdown research-style summary with tables)
- report.csv       (CSV of per-light summary)
- report.tex       (LaTeX table for the main summary)

Usage: python scripts/generate_energy_report.py [path/to/data/energy_data.json]
"""
import json
import sys
from collections import defaultdict
from datetime import datetime
import statistics
import csv


def load_records(path):
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data.get('records', [])


def summarize(records):
    # Consider only 'usage' events (these contain energy_wh)
    usage = [r for r in records if r.get('event') == 'usage']

    total_energy_wh = sum(r.get('energy_wh', 0.0) for r in usage)
    energies = [r.get('energy_wh', 0.0) for r in usage]
    count = len(energies)
    mean_wh = statistics.mean(energies) if energies else 0.0
    median_wh = statistics.median(energies) if energies else 0.0
    min_wh = min(energies) if energies else 0.0
    max_wh = max(energies) if energies else 0.0

    # Per-light aggregation
    by_light = defaultdict(lambda: {'count': 0, 'energy_wh': 0.0})
    by_date = defaultdict(float)
    for r in usage:
        lid = r.get('light_id') or 'unknown'
        e = r.get('energy_wh', 0.0)
        by_light[lid]['count'] += 1
        by_light[lid]['energy_wh'] += e
        # parse date (YYYY-MM-DD)
        ts = r.get('timestamp')
        try:
            d = datetime.fromisoformat(ts).date()
            by_date[str(d)] += e
        except Exception:
            pass

    # Convert per-light to sorted list
    light_rows = []
    for lid, v in by_light.items():
        light_rows.append((lid, v['count'], v['energy_wh']))
    light_rows.sort(key=lambda x: x[2], reverse=True)

    # Daily totals sorted by date
    daily = sorted(by_date.items())

    summary = {
        'total_energy_wh': total_energy_wh,
        'count_usage_events': count,
        'mean_wh': mean_wh,
        'median_wh': median_wh,
        'min_wh': min_wh,
        'max_wh': max_wh,
        'by_light': light_rows,
        'daily': daily,
    }
    return summary


def write_outputs(summary, out_prefix='scripts/report'):
    md_path = out_prefix + '.md'
    csv_path = out_prefix + '.csv'
    tex_path = out_prefix + '.tex'

    # Markdown
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write('# Energy Report\n\n')
        f.write('## Methods\n')
        f.write('Data were extracted from the system logs; only events labeled `usage` were used since they contain explicit `energy_wh` values. Summary statistics are reported in Watt-hours (Wh).\n\n')
        f.write('## Summary Statistics\n')
        f.write('| Metric | Value |\n')
        f.write('|---:|---:|\n')
        f.write(f"| Total energy (Wh) | {summary['total_energy_wh']:.6f} |\n")
        f.write(f"| Number of usage events | {summary['count_usage_events']} |\n")
        f.write(f"| Mean energy per event (Wh) | {summary['mean_wh']:.6f} |\n")
        f.write(f"| Median energy per event (Wh) | {summary['median_wh']:.6f} |\n")
        f.write(f"| Min energy per event (Wh) | {summary['min_wh']:.6f} |\n")
        f.write(f"| Max energy per event (Wh) | {summary['max_wh']:.6f} |\n")
        f.write('\n')

        f.write('## Top 10 Lights by Total Energy (Wh)\n')
        f.write('| Rank | Light ID | Usage events | Total energy (Wh) |\n')
        f.write('|---:|---|---:|---:|\n')
        for i, (lid, cnt, e) in enumerate(summary['by_light'][:10], 1):
            f.write(f'| {i} | {lid} | {cnt} | {e:.6f} |\n')
        f.write('\n')

        f.write('## Daily Energy (sample)\n')
        f.write('| Date | Total energy (Wh) |\n')
        f.write('|---|---:|\n')
        for d, e in summary['daily'][:14]:
            f.write(f'| {d} | {e:.6f} |\n')

    # CSV (per-light full summary)
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['light_id', 'usage_events', 'total_energy_wh'])
        for lid, cnt, e in summary['by_light']:
            writer.writerow([lid, cnt, f'{e:.6f}'])

    # LaTeX table for top 10
    with open(tex_path, 'w', encoding='utf-8') as f:
        f.write('\\begin{table}[ht]\n\\centering\n')
        f.write('\\begin{tabular}{r l r r}\n')
        f.write('\\toprule\\n')
        f.write('Rank & Light ID & Events & Energy (Wh)\\\\\\n')
        f.write('\\midrule\\n')
        for i, (lid, cnt, e) in enumerate(summary['by_light'][:10], 1):
            f.write(f'{i} & {lid} & {cnt} & {e:.6f}\\\\\\n')
        f.write('\\bottomrule\\n')
        f.write('\\end{tabular}\n\\caption{Top 10 lights by total energy consumption (Wh)}\\n\\end{table}\n')

    return md_path, csv_path, tex_path


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else 'data/energy_data.json'
    print(f'Loading records from: {path}')
    records = load_records(path)
    print(f'Loaded {len(records)} records')
    summary = summarize(records)
    md, csvp, tex = write_outputs(summary, out_prefix='scripts/report')
    print('\nGenerated:')
    print(f' - Markdown report: {md}')
    print(f' - CSV (per-light): {csvp}')
    print(f' - LaTeX table: {tex}')


if __name__ == '__main__':
    main()
