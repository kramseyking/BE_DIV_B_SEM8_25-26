#!/usr/bin/env python3
"""
Simple capture utility using picamera2.

Saves JPEG stills to an output directory. Optional hook command can be run
after each capture; use {path} in the hook string which will be replaced by
the saved image path.

Example usage (on Raspberry Pi with picamera2 installed):
  python3 scripts/pi_capture_picamera2.py --outdir /home/pi/captures --count 5 --interval 2

Dependencies:
  - picamera2 (on modern Raspberry Pi OS: sudo apt install -y python3-picamera2)
  - pillow (pip install pillow)

This script is intentionally small and safe for headless use.
"""
import argparse
import datetime
import os
import subprocess
import sys
import time

try:
    from picamera2 import Picamera2
except Exception as e:
    print("Error: cannot import picamera2. Ensure picamera2 is installed and you're running on Raspberry Pi OS.")
    raise


def capture_one(picam2: "Picamera2", outpath: str):
    # capture_image() returns a PIL Image when Pillow is installed
    img = picam2.capture_image()
    img.save(outpath, format="JPEG")
    return outpath


def main():
    parser = argparse.ArgumentParser(description="Capture images using picamera2 and save to a folder")
    parser.add_argument("--outdir", default="captures", help="output directory")
    parser.add_argument("--count", type=int, default=1, help="number of images to capture")
    parser.add_argument("--interval", type=float, default=1.0, help="seconds between captures")
    parser.add_argument("--width", type=int, default=1920, help="image width")
    parser.add_argument("--height", type=int, default=1080, help="image height")
    parser.add_argument("--hook", default=None, help="optional shell command to run after each capture; use {path} as placeholder for image path")
    parser.add_argument("--prefix", default="capture", help="filename prefix")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    try:
        picam2 = Picamera2(camera_num=0)
    except TypeError:
        picam2 = Picamera2()
    config = picam2.create_still_configuration(main={"size": (args.width, args.height)})
    picam2.configure(config)

    try:
        picam2.start()
        # small warm-up
        time.sleep(0.5)

        for i in range(args.count):
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{args.prefix}_{ts}_{i+1}.jpg"
            outpath = os.path.join(args.outdir, filename)

            try:
                capture_one(picam2, outpath)
                print(f"Saved: {outpath}")

                if args.hook:
                    cmd = args.hook.format(path=outpath)
                    # run hook in shell so the user can provide complex commands
                    subprocess.run(cmd, shell=True)

            except Exception as e:
                print(f"Failed to capture image: {e}")

            if i < args.count - 1:
                time.sleep(args.interval)

    except KeyboardInterrupt:
        print("Interrupted by user")
    finally:
        try:
            picam2.stop()
        except Exception:
            pass


if __name__ == "__main__":
    main()
