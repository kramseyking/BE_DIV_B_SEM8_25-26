#!/usr/bin/env pwsh
Write-Host "Formatting Python code with isort and black..."
python -m isort .
python -m black .
Write-Host "Done."
